'use strict';
/* POPSCONTROL 2.8 - real native draw commands; modelled from the user's actual HTML/CSS package.
   No static screen captures. Every panel, button and slider is rendered as interactive primitives.
   System header and climate area are owned by iDrive and are never painted here. */
module.exports=function(View,Recorder,C,clamp,fmt){
const A=require('./ui28assets');
const K={cyan:'#00cfff',cyanSoft:'#38a9e5',mag:'#ff1678',navy:'#020a17',pale:'#f0f7ff',muted:'#a0c2e0',green:'#00ed68',border:'#154a7b',orange:'#ffb32c',red:'#ff275d',purple:'#a54cfa',dim:'#6688a6'};
const risk=['#00ff58','#7ded00','#ffdf1c','#ff8300','#ff0b56'];
const pic=(r,k,x,y,w,h,alpha=1)=>{const im=A.get(k);if(im)r.image(im,x,y,w,h,0,alpha)};
const T=(v,r,s,x,y,z=27,col=K.pale,align)=>v.text(r,s,x,y,z,col,align);
const glow=(r,x,y,w,h,radius,col)=>{
  r.strokeRoundRect(x-5,y-5,w+10,h+10,radius+5,5,col+'25');
  r.strokeRoundRect(x-2,y-2,w+4,h+4,radius+2,3,col+'50');
};
const panel=(r,x,y,w,h,col=K.cyan)=>{
  glow(r,x,y,w,h,22,col);
  r.card(x,y,w,h,19,[[0,'#071a32'],[.16,'#06182d'],[.55,'#030e21'],[1,'#010715']]);
  r.strokeRoundRect(x,y,w,h,19,2,col);
  r.roundRect(x+20,y+6,w-40,3,2,col+'66');
};
const btn=(v,r,id,s,ico,x,y,w,h,active=false,variant='cyan')=>{
 const c=variant==='mag'?K.mag:variant==='orange'?K.orange:K.cyan;
 if(active)glow(r,x,y,w,h,17,K.mag);
 r.card(x,y,w,h,15,active?[[0,'#be2456'],[.35,'#9b0b42'],[1,'#29081a']]:[[0,'#17436b'],[.25,'#071b32'],[.75,'#020b19'],[1,'#010611']]);
 r.strokeRoundRect(x,y,w,h,15,active?3:2,active?'#ff508a':'#3074a5');
 r.roundRect(x+15,y+9,w-30,3,2,active?'#ffafc0b5':'#80ceff66');
 if(ico)pic(r,ico,x+w*.15,y+(h-40)/2,40,40);
 T(v,r,s,x+(ico?w*.54:w*.50),y+(h-30)/2,30,K.pale,'center');
 if(id)v.buttons.push({id,x,y,w,h,kind:'button'});
};
const sectionTitle=(v,r,text,icon,x,y,w)=>{
 if(icon)pic(r,icon,x+26,y+22,45,45);
 T(v,r,text,x+(icon?87:27),y+27,33,K.pale);
 r.line(x+24,y+83,x+w-24,y+83,1,'#387fbd70');
};
const prop=(v,r,id,title,icon,val,max,step,x,y,w,unit,disabled=false,compact=false)=>{
 const z=compact?24:28, i=compact?34:39;
 if(icon)pic(r,icon,x,y,i,i);
 T(v,r,title,x+(icon?i+8:0),y+4,z,K.pale);
 T(v,r,fmt(val,step<1?1:0)+(unit||''),x+w,y+2,z+1,K.pale,'right');
 const ly=y+(compact?52:63),th=compact?10:12;
 r.roundRect(x,ly,w,th,7,'#435c75');r.rampRect(x,ly,w,th,6,risk);
 let p=clamp((val||0)/max,0,1);
 r.circle(x+w*p,ly+th/2,compact?17:20,'#ffffff');
 r.circle(x+w*p,ly+th/2,compact?11:13,disabled?'#8293a5':p>.75?K.red:p>.38?K.orange:K.green);
 if(!disabled&&id)v.sliders.push({id,kind:'slider',x,y:y+26,w,h:78,min:0,max,step});
};
const rpm=(v,r,p,x,y,w)=>{
 T(v,r,'Zakres aktywacji (RPM)',x,y-80,29,K.pale);
 T(v,r,String(p.rpmMin||1000).replace(/\B(?=(\d{3})+(?!\d))/g,' ')+' - '+String(p.rpmMax||7600).replace(/\B(?=(\d{3})+(?!\d))/g,' ')+' RPM',x+w,y-80,29,K.pale,'right');
 r.roundRect(x,y,w,13,7,'#557491');
 const a=x+clamp(((p.rpmMin||1000)-1000)/6600,0,1)*w;
 const b=x+clamp(((p.rpmMax||7600)-1000)/6600,0,1)*w;
 r.roundRect(a,y,Math.max(2,b-a),13,7,'#00f567');r.line(a,y+2,b,y+2,2,'#b6ffcf');
 [a,b].forEach(xx=>{r.circle(xx,y+6,25,'#40ff95aa');r.circle(xx,y+6,20,'#ffffff');r.circle(xx,y+6,13,K.green)});
 T(v,r,'1000',x,y+24,21,K.muted);T(v,r,'7600',x+w,y+24,21,K.muted,'right');
 v.sliders.push({kind:'range',id:'range:rpm',x,y:y-26,w,h:76,min:1000,max:7600,step:100});
};
const stripe=(r,x,y,k=1)=>[['#13befc',0],['#395eff',24],['#ff0053',48]].forEach(([col,d])=>r.quad([[x+(d+17)*k,y],[x+(d+32)*k,y],[x+d*k,y+35*k],[x+(d-15)*k,y+35*k]],col));
const head=(v,r,m)=>{
 r.gradientRect(0,80,2880,82,[[0,'#061c3b'],[.38,'#073565'],[.56,'#041a3e'],[.74,'#501038'],[1,'#04142b']]);
 r.line(0,79,2880,79,2,'#3574c2');r.line(0,160,2880,160,2,'#1565a1');
 r.quad([[1520,81],[1690,81],[1625,158],[1455,158]],'#1e66aa5a');
 r.quad([[2020,81],[2100,81],[2030,158],[1950,158]],'#ff15654f');
 stripe(r,57,100,1.1);T(v,r,'M CONTROL',180,104,43,K.pale);
 r.line(478,102,478,146,2,'#5d93b3');T(v,r,'Pops Controller',516,109,32,K.pale);
 T(v,r,m.settings.carModel||'M3 G80',2215,108,28,K.pale);
 const live=m.frame.hasReal&&!m.frame.demo;const c=live?K.green:m.frame.demo?K.orange:K.red;
 r.circle(2510,129,12,c);T(v,r,live?(m.frame.mode==='PARTIAL'?'DANE CZĘŚCIOWE':'DANE LIVE'):m.frame.demo?'DEMO':'BRAK DANYCH',2542,111,26,c);
};
const nav=(v,r,m)=>{
 const specs=[['comfort','Comfort','comfort'],['sport','Sport','sport'],['sportplus','Sport+','sportplus'],['pn','P / N','gear']];
 let x=63;for(let i=0;i<specs.length;i++){const q=specs[i];btn(v,r,'mode:'+q[0],q[1],q[2],x,185,467,74,m.settings.mode===q[0]);x+=481;}
 btn(v,r,'page:camera','Kamera','camera',2000,185,395,74,false);
 btn(v,r,'page:settings','Ustawienia','settings',2415,185,407,74,m.page==='settings');
};
const rowLive=(v,r,m,x,y,w,h,camera)=>{
 panel(r,x,y,w,h,K.cyan);sectionTitle(v,r,'PARAMETRY LIVE','diagnostic',x,y,w);
 const d=m.frame.values;
 let rows=[['power','Aktualna moc',fmt(d.powerHp)+' KM'],['rpm','Obroty silnika',fmt(d.rpm)+' RPM'],['boost','Doładowanie',fmt(d.boost,2)+' bar'],['torque','Moment obrotowy',fmt(d.torque)+' Nm'],['oil','Temp. oleju',fmt(d.oil)+' °C'],['coolant','Płyn chłodzący',fmt(d.coolant)+' °C']];
 if(camera)rows.splice(1,0,['rpm','Prędkość',fmt(d.speed)+' km/h']);
 let step=(h-110)/rows.length;
 rows.forEach((q,i)=>{const yy=y+94+i*step;
  r.line(x+26,yy+step-1,x+w-26,yy+step-1,1,'#32618475');pic(r,q[0],x+26,yy+9,38,38);
  T(v,r,q[1],x+78,yy+13,camera?24:28,K.pale);
  T(v,r,q[2],x+w-24,yy+13,camera?26:28,K.white,'right');
 });
};
const status=(v,r,m)=>{
 const live=m.frame.hasReal&&!m.frame.demo;
 r.card(49,775,2783,54,9,[[0,'#073c64'],[.5,'#07172d'],[.92,'#08213c'],[1,'#2f1444']]);
 r.strokeRoundRect(49,775,2783,54,9,1,'#2e9de0');
 r.circle(82,801,11,live?K.green:m.frame.demo?K.orange:K.red);
 T(v,r,live?'LIVE':m.frame.demo?'DEMO':'BRAK DANYCH',104,783,24,live?K.green:K.orange);
 T(v,r,'RPM '+fmt(m.frame.values.rpm)+'  |  KM/H '+fmt(m.frame.values.speed)+'  |  BŁĘDY '+(m.errors||0),260,783,24,K.pale);
};
const drawHome=(v,r,m)=>{
 head(v,r,m);nav(v,r,m);
 const mode=m.settings.mode,p=m.settings.profile[mode],hasFlame=(mode==='sportplus'||mode==='pn');
 const x=48,y=285,h=472,lw=hasFlame?1265:1915;
 panel(r,x,y,lw,h,K.cyan);stripe(r,x+41,y+22,.74);
 const modeName={comfort:'COMFORT',sport:'SPORT',sportplus:'SPORT+',pn:'P/N'}[mode];
 T(v,r,'POPS / PROFIL '+modeName,x+133,y+31,36,K.pale);
 pic(r,'exhaust_soft',x+lw-620,y+20,580,138,.90);
 r.line(x+28,y+118,x+lw-28,y+118,1,'#235174');
 rpm(v,r,p,x+70,y+224,lw-140);
 const gx=x+50, gy=y+355, sp=(lw-115)/3, w=sp-29;
 prop(v,r,'profile:duration','Długość','rpm',p.duration,4,.1,gx,gy,w,' s',mode==='comfort',true);
 prop(v,r,'profile:aggression','Moc','power',p.aggression,100,5,gx+sp,gy,w,' %',mode==='comfort',true);
 prop(v,r,'profile:delay','Opóźnienie','rpm',p.delay,1000,25,gx+2*sp,gy,w,' ms',mode==='comfort',true);
 const rx=2057,rw=771;
 if(hasFlame){const fx=1330,fw=709;panel(r,fx,y,fw,h,K.mag);
  sectionTitle(v,r,'FLAME MODE','flame',fx,y,fw);
  const f=m.settings.flameProfiles[mode];
  pic(r,'flame_soft',fx+180,y+104,fw-215,142,.88);
  const bx=fx+fw-174,by=y+21;
  r.roundRect(bx,by,143,62,31,f.enabled?'#069e40':'#263b51');
  r.strokeRoundRect(bx,by,143,62,31,3,f.enabled?K.green:K.dim);
  r.circle(f.enabled?bx+108:bx+35,by+31,24,'#ffffff');
  v.buttons.push({id:'flame:toggle',x:bx,y:by,w:143,h:62,kind:'button'});
  const fy=y+178,aw=fw-70;
  prop(v,r,'flame:duration','Długość','rpm',f.duration,4,.1,fx+35,fy,aw,' s',!f.enabled,true);
  prop(v,r,'flame:power','Moc','power',f.power,100,5,fx+35,fy+89,aw,' %',!f.enabled,true);
  prop(v,r,'flame:delay','Opóźnienie','rpm',f.delay,1000,25,fx+35,fy+178,aw,' ms',!f.enabled,true);
  T(v,r,'USTAWIENIA LOKALNE - BEZ ZAPISU ECU',fx+37,y+435,19,K.muted);
 }
 rowLive(v,r,m,hasFlame?rx:1985,y,hasFlame?rw:843,h,false);
 status(v,r,m);
};
const drawCamera=(v,r,m)=>{
 // Never claim the static parking photo is from BMW's OEM cameras.
 const x=42,y=91,w=2045,h=721;
 panel(r,x,y,w,h,K.orange);
 sectionTitle(v,r,'KAMERA / PODGLĄD DEMO','camera',x,y,w);
 r.card(x+24,y+94,w-48,h-113,17,[[0,'#071326'],[1,'#020714']]);
 pic(r,'parking_demo',x+31,y+101,w-62,h-134,1);
 r.roundRect(x+51,y+112,730,51,11,'#040c16d9');
 r.strokeRoundRect(x+51,y+112,730,51,11,2,'#ffb32c');
 T(v,r,'DEMO - BRAK SYGNAŁU OEM',x+73,y+122,28,K.orange);
 r.roundRect(x+51,y+h-96,w-102,54,8,'#03101ad9');
 T(v,r,'Przykładowy obraz parkingu. Źródło OEM jest niedostępne, diagnostyka w Ustawieniach.',x+78,y+h-83,23,K.pale);
 rowLive(v,r,m,2103,y,728,h,true);
 // Top-right small close button; has its own hit target.
 const cx=2736,cy=104;r.card(cx,cy,72,62,12,[[0,'#4e1d36'],[1,'#170d1f']]);
 r.strokeRoundRect(cx,cy,72,62,12,2,K.mag);T(v,r,'X',cx+36,cy+14,31,K.pale,'center');
 v.buttons.push({id:'page:home',x:cx,y:cy,w:72,h:62,kind:'button'});
};
const cell=(v,r,title,icon,x,y,w,h,col=K.cyan)=>{panel(r,x,y,w,h,col);sectionTitle(v,r,title,icon,x,y,w);};
const drawSettings=(v,r,m)=>{
 head(v,r,m);nav(v,r,m);
 const x=52,y=281,h=258,sp=15,w=912;
 cell(v,r,'Połączenie','check',x,y,w,h);
 const stat=[['Renderer MGU',m.touchSupported?'połączono':'niepotwierdzony'],['Sterowanie',m.touchSupported?'aktywne':'niepotwierdzone'],['Dane LIVE',m.frame.hasReal?'odbierane':'brak danych']];
 stat.forEach((q,i)=>{const yy=y+106+i*51;r.circle(x+42,yy+11,10,q[1]==='brak danych'?K.orange:K.green);T(v,r,q[0],x+73,yy,26,K.pale);T(v,r,q[1],x+w-35,yy,25,K.pale,'right');});
 const sx=x+w+sp, sw=960;cell(v,r,'Diagnostyka i debug','diagnostic',sx,y,sw,h,K.purple);
 btn(v,r,'page:errors','Otwórz zaawansowane logi','file',sx+37,y+103,sw-74,63,false,'mag');
 T(v,r,'Ostatni błąd: '+(m.errors?'szczegóły w logach':'brak'),sx+43,y+184,23,K.pale);
 const kx=sx+sw+sp,kw=2828-kx;cell(v,r,'Kamera','camera',kx,y,kw,h);
 T(v,r,'Kamera OEM: brak dostępu',kx+32,y+115,25,K.orange);
 btn(v,r,'page:camera','Sprawdź kamerę','camera',kx+30,y+172,kw-60,57);
 const ly=562,lh=192;
 cell(v,r,'Interfejs i model BMW','settings',x,ly,1382,lh);
 const models=['M3 Competition','M3 CS','M3 CSL','M3','M3 G80','M4 G82','M4 Competition','M4 CSL','M2 G87','M2 CS'];
 T(v,r,'Model auta:',x+40,ly+115,30,K.muted);
 const selected=m.settings.carModel||'M3 G80';T(v,r,selected,x+575,ly+115,29,K.pale);
 btn(v,r,'model:prev','<','',x+930,ly+104,111,61);
 btn(v,r,'model:next','>','',x+1060,ly+104,110,61);
 cell(v,r,'ECU i kopie','engine',1450,ly,1378,lh,K.purple);
 T(v,r,'ECU silnika - tylko odczyt',1494,ly+111,31,K.pale);
 btn(v,r,'backup','Kopia ustawień','copy',2184,ly+98,608,65);
 status(v,r,m);
};
const sortRows=m=>({all:m.debugEntries||[],errors:m.errorRecords||[]});
const drawErrors=(v,r,m)=>{
 const full=!!m.fullDebug;const x=40,y=88,w=2798,h=730;
 panel(r,x,y,w,h,K.purple);
 pic(r,'file',x+28,y+18,48,48);
 T(v,r,full?'PEŁNY DEBUG / 5 KOLUMN LOGÓW':'ZAAWANSOWANA DIAGNOSTYKA / BŁĘDY',x+95,y+20,37,K.pale);
 const list=full?(m.debugEntries||[]):(m.errorRecords||[]);
 const per=full?50:12,pages=Math.max(1,Math.ceil(list.length/per)),pg=clamp(m.errorPage||0,0,pages-1);
 T(v,r,'BŁĘDY '+(m.errors||0)+'  |  STRONA '+(pg+1)+' / '+pages,x+w-35,y+27,27,K.pale,'right');
 btn(v,r,'debug:toggle',full?'TYLKO BŁĘDY':'PEŁNY DEBUG','diagnostic',x+w-488,y+82,444,58,full,'mag');
 const areaY=y+159,areaH=485,rows=list.slice(pg*per,(pg+1)*per);
 if(full){
  const colw=(w-58)/5;
  for(let c=0;c<5;c++){
   const xx=x+18+c*colw;
   panel(r,xx,areaY,colw-12,areaH,c===0?K.mag:K.cyan);
   T(v,r,'LOGI '+(c+1),xx+21,areaY+13,27,K.pale);
   for(let k=0;k<10;k++){
    const e=rows[c*10+k];if(!e)continue;
    const yy=areaY+59+k*40,level=e.level||'INFO';
    const tone=level==='ERROR'?K.red:level==='WARN'?K.orange:K.muted;
    if(k%2===0)r.roundRect(xx+10,yy-3,colw-31,39,3,'#19324a65');
    T(v,r,(e.code||'LOG').slice(0,22),xx+15,yy,18,tone);
    T(v,r,String(e.message||'').replace(/\s+/g,' ').slice(0,50),xx+15,yy+19,15,K.pale);
   }
  }
 }else{
  panel(r,x+18,areaY,w-36,areaH,K.cyan);
  T(v,r,'POZIOM   |   KOD   |   OSTATNIO   |   KOMUNIKAT',x+44,areaY+12,25,K.muted);
  if(rows.length===0)T(v,r,'BRAK AKTYWNYCH BŁĘDÓW W RAPORCIE',x+80,areaY+148,36,K.green);
  rows.forEach((e,i)=>{const yy=areaY+56+i*34;
    if(i%2===0)r.roundRect(x+32,yy-1,w-68,34,2,'#1238548c');
    const lev=e.level||'WARN',col=lev==='ERROR'?K.red:lev==='WARN'?K.orange:K.pale;
    T(v,r,lev,x+49,yy+3,20,col);
    T(v,r,String(e.code||'UNKNOWN').slice(0,24),x+255,yy+3,20,col);
    T(v,r,String(e.at||'').slice(11,19),x+620,yy+3,19,K.muted);
    T(v,r,String(e.message||'').replace(/\s+/g,' ').slice(0,148),x+830,yy+3,19,K.pale);
  });
 }
 const actions=[['error:prev','Poprzednia'],['error:next','Następna'],['error:refresh','Odśwież'],['retry','Połącz ponownie'],['page:settings','Ustawienia']];
 actions.forEach((q,i)=>btn(v,r,q[0],q[1],'',x+22+i*554,y+h-79,530,60,false,i===4?'mag':'cyan'));
};
const previous=View.prototype.draw;
View.prototype.draw=function(m){if(this.config.kind!=='pops')return previous.call(this,m);
 this.model=m;this.buttons=[];this.sliders=[];
 const r=new Recorder(2880,960,{textScale:1});r.clear([0,0,0,0]);
 r.clip(0,76,2880,764);
 r.gradientRect(0,76,2880,764,[[0,'#020610'],[.42,'#051428'],[.8,'#030918'],[1,'#01030a']]);
 for(let i=0;i<9;i++)r.quad([[i*407,79],[i*407+7,79],[i*407-280,839],[i*407-287,839]],'#1b68b316');
 r.line(0,79,2880,79,3,'#5388db');
 if(m.page==='camera')drawCamera(this,r,m);else if(m.page==='errors')drawErrors(this,r,m);
 else if(m.page==='settings'){drawSettings(this,r,m);}else if(m.page==='home'){drawHome(this,r,m);}
 else {drawHome(this,r,m);}
 if(m.notice){r.roundRect(570,734,1730,37,9,'#422138');T(this,r,String(m.notice).slice(0,92),597,736,21,K.orange);}
 r.noclip();return r;
};
};
