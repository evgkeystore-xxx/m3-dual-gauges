'use strict';
/*
 * M CONTROL Reference Fit 1.9 — real native canvas drawing commands.
 * Base reference: two user-provided M Control images, visually reconstructed as
 * usable, data-driven widgets. Nothing is a photographed/static UI background.
 * Safety boundaries: x=0..2880; draw only y=76..840; no ECU writes in view.
 */
module.exports=function(View,C,ART,clamp,fmt){
 const PREMIUM=require('./icons21');
 const P={bg:'#030914',ink:'#061328',nav:'#0c2548',card:'#071a31',glass:'#103257',white:'#f5faff',dim:'#d4e5fc',muted:'#9fb6d5',blue:'#21b9ff',ice:'#72e9ff',purple:'#b44bff',red:'#ff2259',hot:'#ff688f',green:'#2ff5b1',gold:'#f1c785'};
 const no=(n)=>n==null||!Number.isFinite(n)?'--':String(n);
 const format=(n,d=0)=>n==null||!Number.isFinite(n)?'--':Number(n).toFixed(d);
 const T=(r,s,x,y,size,color,align)=>r.text(String(s),x,y+size*.86,size,color||P.white,{align:align||'left',font:'m3suite-raster-v1'});
 const line=(r,x1,y1,x2,y2,c='#42658d',w=1)=>r.line(x1,y1,x2,y2,w,c);
 const round=(r,x,y,w,h,rad,color)=>r.roundRect(x,y,w,h,rad,color);
 const icon=(r,name,x,y,w,h)=>{const it=PREMIUM.icon(name)||ART.icon(name);if(it)r.image(it,x,y,w,h||w,0);};
 const stripe=(r,x,y,h)=>{const colors=['#29bbff','#5c76ef','#fc2862'];colors.forEach((c,i)=>r.quad([[x+i*18,y],[x+12+i*18,y],[x-4+i*18,y+h],[x-16+i*18,y+h]],c));};
 const glow=(r,x,y,w,h,col)=>{r.strokeRoundRect(x-5,y-5,w+10,h+10,21,5,col+'24');r.strokeRoundRect(x-2,y-2,w+4,h+4,19,3,col+'63');};
 const PANEL_GRAD=[[0,'#153a67'],[.10,'#0d2b4e'],[.28,'#092440'],[.68,'#071b32'],[1,'#051327']];
 function panel(r,x,y,w,h,col=P.blue){
   glow(r,x,y,w,h,col);
   r.card(x,y,w,h,18,PANEL_GRAD);r.strokeRoundRect(x,y,w,h,18,2,col);r.roundRect(x+14,y+18,2,h-35,2,col+'65');
   r.roundRect(x+20,y+11,w-40,4,2,col+'89');r.gradientRect(x+32,y+21,w-64,2,[[0,col+'00'],[.55,col+'4b'],[1,col+'00']]);
   r.quad([[x+w*.69,y+17],[x+w*.88,y+17],[x+w*.65,y+h-14],[x+w*.52,y+h-14]],'#84b4f006');
   r.gradientRect(x+13,y+h-16,w-26,5,[[0,'#14294b00'],[.5,col+'29'],[1,'#00000000']]);
 }
 function heading(r,text,x,y,iconName,color=P.ice,size=34){
   icon(r,iconName,x+8,y+5,55,55);T(r,text,x+75,y+9,size,P.white);
 }
 function blueBtn(r,view,id,label,x,y,w,h,active=false,ic=null,accent=P.blue,disabled=false){
   if(active){r.card(x-7,y-5,w+14,h+10,18,[[0,accent+'72'],[.48,accent+'34'],[1,'#020914']]);r.strokeRoundRect(x-6,y-5,w+12,h+10,17,4,accent+'bb');}
   r.card(x,y,w,h,15,active?[[0,'#8c174a'],[.22,'#c51652'],[.52,'#fb2658'],[.82,'#9a1546'],[1,'#4c1333']]:[[0,'#244979'],[.16,'#132e51'],[.48,'#0a203c'],[.83,'#08152a'],[1,'#040e20']]);
   r.strokeRoundRect(x,y,w,h,15,active?4:2,active?'#ff96b4':'#386ca3');
   round(r,x+14,y+7,w-28,4,2,active?'#ffd8e9af':'#93d6ff88');
   if(ic){icon(r,ic,x+25,y+(h-48)/2,48,48);}
   const fs=Math.min(32,h*.42);
   if(ic)T(r,label,x+w*.55,y+(h-fs)/2,fs,disabled?'#758ca8':P.white,'center');
   else T(r,label,x+w/2,y+(h-fs)/2,fs,disabled?'#758ca8':P.white,'center');
   if(id&&!disabled)view.buttons.push({id,kind:'button',x,y,w,h});
 }
 function nativeHeader(r,m,kind){
   r.clear([0,0,0,0]);
   r.gradientRect(0,76,2880,764,[[0,'#050f24'],[.3,'#071b34'],[.70,'#06162b'],[1,'#030915']]);
   // M-shaped carbon highlights, bounded to the app display
   for(let n=0;n<8;n++){let x=n*433-180;r.quad([[x,77],[x+7,77],[x-300,840],[x-307,840]],'#3d73ac0b');}
   r.quad([[1500,85],[1780,85],[1620,174],[1340,174]],'#0b468b62');
   r.quad([[1770,85],[1885,85],[1735,174],[1620,174]],'#123a7b75');
   r.quad([[1902,85],[1999,85],[1850,174],[1754,174]],'#c522505a');
   r.quad([[2002,85],[2040,85],[1890,174],[1854,174]],'#ff2b6180');
   r.gradientRect(0,78,2880,3,[[0,'#1f5da5'],[.35,'#469de8'],[.65,'#b1438e'],[1,'#3e60bc']]);
   r.gradientRect(0,838,2880,2,[[0,'#11406c'],[.5,'#1497e4'],[.80,'#ff306a'],[1,'#0f4d84']]);
   r.card(0,86,2880,90,0,[[0,'#0e2b51'],[.3,'#0b2448'],[.62,'#0a1c39'],[1,'#061529']]);
   stripe(r,68,114,43);
   T(r,'M',157,109,48,P.white); T(r,'CONTROL',206,118,35,P.white);
   line(r,518,111,518,162,'#809fc6',2);
   T(r,kind==='pops'?'Pops Studio':kind==='dual'?'Dual Gauges':'Cockpit Studio',550,121,32,'#d3e5fe');
   const c=m.frame.demo?P.gold:m.frame.hasReal?P.green:P.red;
   T(r,'M3 G80',2340,122,28,P.white);r.circle(2543,140,12,c);
   T(r,m.frame.demo?'DEMO':m.frame.hasReal?'DANE LIVE':'BRAK DANYCH',2571,122,28,c);
 }
 View.prototype.backdrop=function(r){r.clear([0,0,0,0]);};
 View.prototype.header=function(r,m){nativeHeader(r,m,this.config.kind);};
 View.prototype.popsNav=function(r,m){
   const mode=m.settings.mode;
   [['comfort','Comfort','eco'],['sport','Sport','sport'],['sportplus','Sport+','sportplus'],['pn','P / N','gear']].forEach((a,i)=>blueBtn(r,this,'mode:'+a[0],a[1],55+i*479,194,456,76,mode===a[0]&&m.page==='home',a[2],P.red));
   blueBtn(r,this,'page:camera','Kamera',1986,194,394,76,m.page==='camera','camera',P.blue);
   blueBtn(r,this,'page:settings','Ustawienia',2400,194,424,76,m.page==='settings','settings',P.red);
 };
 function compactTrack(r,view,p,x,y,w){
   T(r,'AKTYWACJA  (ZAKRES RPM)',x,y-78,29,'#c7d9f5');T(r,p.rpmMin+' - '+p.rpmMax+' RPM',x+w,y-78,29,P.white,'right');
   round(r,x,y,w,15,8,'#355476');
   const lx=x+clamp((p.rpmMin-1000)/6600,0,1)*w,rx=x+clamp((p.rpmMax-1000)/6600,0,1)*w;
   round(r,lx,y,Math.max(4,rx-lx),15,7,'#2aaaf8');round(r,lx+(rx-lx)*.46,y,Math.max(4,(rx-lx)*.54),15,7,'#fa3c72');r.line(lx,y+3,rx,y+3,2,'#c9efff7b');
   for(const [pos,c] of [[lx,P.blue],[rx,P.blue]]){r.circle(pos,y+7.5,25,'#cbeaff33');r.circle(pos,y+7.5,19,'#f8ffff');r.circle(pos,y+7.5,12,c);}
   T(r,'1000',x,y+25,21,'#92aeca');T(r,'7600',x+w,y+25,21,'#92aeca','right');
   view.sliders.push({kind:'range',id:'range:rpm',x,y:y-24,w,h:83,min:1000,max:7600,step:100});
 }
 function compactSlider(r,view,id,title,ic,val,min,max,step,x,y,w,suffix,disabled){
   icon(r,ic,x,y-56,43,43);T(r,title,x+53,y-49,27,P.white);T(r,format(val,step<1?1:0)+(suffix||''),x+w,y-49,27,P.white,'right');
   round(r,x,y,w,14,7,'#243955');
   const progress=w*clamp((val-min)/(max-min),0,1);if(progress>1){round(r,x,y,progress,14,7,'#ff225d');r.line(x+4,y+3,x+progress,y+3,2,'#ffe0edbb');}
   const px=x+progress;r.circle(px,y+7,22,'#ff9cbf66');r.circle(px,y+7,16,P.white);r.circle(px,y+7,9,P.red);
   if(!disabled)view.sliders.push({kind:'slider',id,x,y:y-23,w,h:75,min,max,step});
 }
 View.prototype.telemetry=function(r,m){
   const x=2098,y=294,w=728,h=453;panel(r,x,y,w,h,P.blue);heading(r,'PARAMETRY LIVE',x+22,y+12,'wave',32);
   line(r,x+27,y+80,x+w-25,y+80,'#4d79a6',1);
   const v=m.frame.values;const rows=[
    ['AKTUALNA MOC',v.powerHp==null?'--':format(v.powerHp),'KM','power'],
    ['OBROTY SILNIKA',v.rpm==null?'--':format(v.rpm),'RPM','rpm'],
    ['DOŁADOWANIE',format(v.boost,2),'bar','boost'],
    ['MOMENT',format(v.torque),'Nm','torque'],
    ['TEMP. OLEJU',format(v.oil),'°C','oil'],
    ['PŁYN CHŁODZĄCY',format(v.coolant),'°C','coolant']];
   rows.forEach((row,i)=>{const yy=y+93+i*57;
    if(i)line(r,x+17,yy-1,x+w-17,yy-1,'#2f5274',1);
    icon(r,row[3],x+27,yy+10,43,43);T(r,row[0],x+88,yy+16,25,'#d2e5fc');
    T(r,row[1]+' '+row[2],x+w-23,yy+10,30,P.white,'right');
   });
 };
 View.prototype.pops=function(r,m){
   const mode=m.settings.mode,p=m.settings.profile[mode];const x=51,y=294,w=1424,h=453;
   panel(r,x,y,w,h,P.blue);stripe(r,x+48,y+33,44);
   T(r,'PROFIL '+(mode==='sportplus'?'SPORT+':mode==='pn'?'P / N':mode.toUpperCase())+'  /  USTAWIENIA LOKALNE',x+117,y+26,37,P.white);
   T(r,'MHD POPS - BRAK MODYFIKACJI ECU',x+115,y+74,25,'#c0a8c7');
   line(r,x+36,y+113,x+w-36,y+113,'#345a7c',1);
   compactTrack(r,this,p,x+80,y+233,w-160);
   // Dividers match the photographed three sliders
   line(r,x+455,y+319,x+455,y+431,'#28456a',1);line(r,x+918,y+319,x+918,y+431,'#28456a',1);
   compactSlider(r,this,'profile:duration','DŁUGOŚĆ','timer',p.duration,0,4,.1,x+75,y+399,337,' s',mode==='comfort');
   compactSlider(r,this,'profile:aggression','MOC','power',p.aggression,0,100,5,x+523,y+399,335,' %',mode==='comfort');
   compactSlider(r,this,'profile:delay','OPÓŹNIENIE','delay',p.delay,0,1000,25,x+985,y+399,340,' ms',mode==='comfort');
   const px=1494,pw=578;panel(r,px,y,pw,h,P.purple);heading(r,'FLAME MODE',px+22,y+18,'flame',33);
   const f=(m.settings.flameProfiles||{})[mode];const allowed=!!f&&mode!=='comfort';
   // This local Flame Mode NEVER sends ECU commands. Separate ON/OFF and exactly three sliders.
   T(r,allowed?'USTAWIENIA DLA '+(mode==='pn'?'P/N':mode.toUpperCase()):'COMFORT / NIEDOSTĘPNE',px+31,y+79,22,'#bcd0ee');
   const bx=px+pw-183,by=y+74;
   r.roundRect(bx,by,150,52,26,allowed&&f.enabled?'#3e0d2d':'#112844');
   r.strokeRoundRect(bx,by,150,52,26,3,allowed&&f.enabled?P.red:'#40618a');
   r.circle(bx+(allowed&&f.enabled?122:27),by+26,20,allowed&&f.enabled?'#ff4f89':'#b8d2e9');
   T(r,allowed&&f.enabled?'ON':'OFF',bx+75,by+10,25,P.white,'center');
   if(allowed)this.buttons.push({id:'flame:toggle',kind:'button',x:bx,y:by,w:150,h:52});
   if(allowed){
     const at=px+33, ww=pw-68;
     const spec=[['flame:duration','DŁUGOŚĆ','timer',f.duration,0,4,.1,' s'],['flame:power','MOC','power',f.power,0,100,5,' %'],['flame:delay','OPÓŹNIENIE','delay',f.delay,0,1000,25,' ms']];
     spec.forEach((a,i)=>{const yy=y+192+i*76;const val=a[3],prog=clamp((val-a[4])/(a[5]-a[4]),0,1);
       icon(r,a[2],at,yy-21,30,30);T(r,a[1],at+39,yy-19,23,'#f5edff');T(r,format(val,a[6]<1?1:0)+a[7],at+ww,yy-19,24,P.white,'right');
       r.roundRect(at,yy+21,ww,11,6,'#304463');if(prog>0)r.roundRect(at,yy+21,Math.max(3,ww*prog),11,5,P.red);
       const knob=at+ww*prog;r.circle(knob,yy+26,16,'#ffffff');r.circle(knob,yy+26,8,P.red);
       if(f.enabled)this.sliders.push({kind:'slider',id:a[0],x:at,y:yy+4,w:ww,h:54,min:a[4],max:a[5],step:a[6]});
     });
   }else{icon(r,'shield',px+190,y+177,96,96);T(r,'Flame Mode wyłączony',px+pw/2,y+291,27,P.gold,'center');}
   T(r,'PROFIL LOKALNY / ECU BEZ ZAPISU',px+pw/2,y+408,19,'#b7bbdc','center');
   this.telemetry(r,m);
 };
 View.prototype.popsSettings=function(r,m){
   // Two photographed reference screens: 3 cards upper row, 2 larger cards lower row.
   const y=294,h=257;
   panel(r,51,y,986,h,P.blue);heading(r,'Połączenie',77,y+12,'link',37);
   const items=[['Renderer MGU',m.touchSupported?'połączono':'niepotwierdzony',m.touchSupported],['Sterowanie',m.touchSupported?'aktywne':'niepotwierdzone',m.touchSupported],['Dane LIVE',m.frame.hasReal?'odbierane':'niedostępne',m.frame.hasReal]];
   items.forEach((a,i)=>{const yy=y+92+i*50;r.circle(112,yy+13,11,a[2]?P.green:P.gold);T(r,a[0],148,yy-5,28,P.white);T(r,a[1],991,yy-5,26,a[2]?'#a9f8cf':'#e4be88','right');});
   panel(r,1067,y,1017,h,P.purple);heading(r,'Diagnostyka i debug',1098,y+10,'wave',36);
   blueBtn(r,this,'page:errors','Otwórz zaawansowane logi',1120,y+79,917,65,false,'logs',P.purple);
   icon(r,'shield',1128,y+163,39,39);T(r,'Ostatni błąd: '+(m.errors?'szczegóły w logach':'brak'),1188,y+169,26,P.dim);
   icon(r,'wave',1128,y+209,39,39);T(r,'Zdarzenia wejścia: '+m.touchEvents+'   /   RHMI: '+(m.touchSupported?'gotowy':'niepotwierdzony'),1188,y+209,24,'#c3d6ee');
   panel(r,2111,y,715,h,P.blue);heading(r,'Kamera',2138,y+13,'camera',36);
   r.circle(2159,y+100,11,P.gold);T(r,'Kamera OEM: niedostępna',2190,y+88,25,P.gold);
   blueBtn(r,this,'page:camera','Test kamery',2142,y+135,651,53,false,'camera',P.blue);
   blueBtn(r,this,'page:camera','Skonfiguruj',2142,y+200,651,45,false,'settings',P.blue);
   const ly=570,lh=177;
   panel(r,51,ly,1317,lh,P.blue);heading(r,'Interfejs',75,ly+4,'monitor',32);icon(r,'wave',1295,ly+12,41,41);this.buttons.push({id:'page:graphs',kind:'button',x:1291,y:ly+10,w:52,h:48});
   const opts=[['Motyw: M Control','palette'],['Jasność: automatyczna','brightness'],['Układ: zoptymalizowany','settings']];
   opts.forEach((a,i)=>{const yy=ly+49+i*40;if(i)line(r,73,yy-3,1328,yy-3,'#46698d8c',1);
     icon(r,a[1],90,yy+1,34,34);T(r,a[0],143,yy+1,26,'#d8e5fb');T(r,'>',1327,yy+1,27,P.white,'right');
     this.buttons.push({id:'page:advanced',kind:'button',x:73,y:yy,w:1254,h:38});
   });
   panel(r,1392,ly,1434,lh,P.purple);heading(r,'ECU silnika',1420,ly+8,'engine',33);
   icon(r,'shield',1451,ly+87,37,37);T(r,'ECU silnika - tylko odczyt',1516,ly+90,27,P.dim);
   const image=PREMIUM.icon('engineCover')||ART.icon('engineCover');if(image)r.image(image,2195,ly+19,510,143,0);
   stripe(r,2756,ly+100,49);
 };

 View.prototype.popsSettingsExtra=function(r,m){
   const y=294;
   panel(r,51,y,1358,449,P.blue);heading(r,'Ustawienia dodatkowe',83,y+18,'settings',36);
   T(r,'Przewiń w górę, aby wrócić do diagnostyki',105,y+90,26,P.muted);
   blueBtn(r,this,'page:params','Parametry LIVE',100,y+141,580,82,false,'rpm');
   blueBtn(r,this,'page:graphs','Wykresy 60 s',730,y+141,585,82,false,'wave');
   blueBtn(r,this,'backup','Kopia ustawień aplikacji',100,y+250,580,82,false,'logs');
   blueBtn(r,this,'autoDemo',m.settings.autoDemo?'DEMO automatyczne: WŁ.':'DEMO automatyczne: WYŁ.',730,y+250,585,82,false,'shield');
   panel(r,1450,y,1376,449,P.purple);heading(r,'Bezpieczeństwo ECU',1493,y+19,'engine',37);
   icon(r,'shield',1498,y+138,64,64);T(r,'Tylko odczyty. Brak flashowania mapy.',1590,y+144,30,P.dim);
   icon(r,'logs',1498,y+222,64,64);T(r,'Kopia zapisuje ustawienia aplikacji, nie ECU.',1590,y+228,27,P.dim);
   blueBtn(r,this,'retry','Połącz ponownie',1532,y+336,530,68,false,'link');
   blueBtn(r,this,'restore','Przywróć ustawienia aplikacji',2110,y+336,647,68,false,'settings');
 };
 View.prototype.scrollIndicator=function(r,m){
   if(m.page!=='settings')return;
   const down=!m.settingsScroll;
   round(r,2836,307,11,432,5,'#254b70');
   round(r,2834,down?314:549,15,176,7,down?P.ice:P.red);
   T(r,down?'▼':'▲',2841,down?565:343,24,P.white,'center');
   this.buttons.push({id:down?'settings:down':'settings:up',kind:'button',x:2798,y:down?541:308,w:76,h:205});
 };
 View.prototype.status=function(r,m){
   const f=m.frame,isLive=f.hasReal&&!f.demo,accent=f.demo?P.gold:isLive?P.green:P.red;
   r.card(51,779,2775,52,11,[[0,'#0a3658'],[.35,'#072647'],[.8,'#09213d'],[1,'#0a274a']]);r.strokeRoundRect(51,779,2775,52,11,2,'#3c8bc8');
   round(r,67,784,2750,3,2,'#3c9ade61');
   r.circle(91,804,11,accent);T(r,f.demo?'DEMO':isLive?'LIVE':'OFFLINE',113,787,26,accent);
   T(r,'RPM '+format(f.values.rpm)+'  |  KM/H '+format(f.values.speed)+'  |  BŁĘDY '+(m.errors||0),262,786,24,'#dcf0ff');
   // Decorative M stripes like reference. Status tap opens Settings/Debug.
   for(let i=0;i<3;i++)r.quad([[2679+i*29,787],[2711+i*29,787],[2689+i*29,823],[2658+i*29,823]],[P.blue,'#577af7',P.red][i]);
   this.buttons.push({id:'page:settings',kind:'button',x:51,y:779,w:2775,h:52});
 };
 View.prototype.popsNav=View.prototype.popsNav;
 // Match look of the reference in the other two apps without changing their proven UI behavior.
 View.prototype.tabs=function(r,m){if(this.config.kind==='pops')return;
   const a=[['page:home','Zegary','rpm'],['page:themes','Motywy','m'],['page:params','Parametry LIVE','wave'],['page:settings','Ustawienia','settings']];
   a.forEach((it,i)=>blueBtn(r,this,it[0],it[1],55+i*705,194,678,76,m.page===it[0].slice(5),it[2],i===0?P.red:P.blue));
 };
};
