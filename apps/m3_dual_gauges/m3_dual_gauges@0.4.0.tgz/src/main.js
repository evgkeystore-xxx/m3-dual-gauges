'use strict';
const fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..');
const DATA=path.join(ROOT,'..','data');
function makeDir(p){if(!fs.existsSync(p)){makeDir(path.dirname(p));try{fs.mkdirSync(p,0o700);}catch(e){if(!fs.existsSync(p))throw e;}}}
function bootLog(s){try{makeDir(DATA);const f=path.join(DATA,'m3-boot.log');if(fs.existsSync(f)&&fs.statSync(f).size>262144)fs.renameSync(f,f+'.1');fs.appendFileSync(f,new Date().toISOString()+' '+s+'\n',{mode:0o600});}catch(e){console.error('[M3SUITE BOOT LOG] '+e.stack);}console.error('[M3SUITE BOOT] '+s);}
bootLog('ENTRY module loaded; root='+ROOT);
let app=null,diag=null;
try{
 const config=JSON.parse(fs.readFileSync(path.join(ROOT,'config','app.json'),'utf8'));
 const D=require(path.join(ROOT,'lib','diagnostics.js'));
 diag=new D.Diagnostics(config,DATA,console);
 process.on('unhandledRejection',e=>{bootLog('UNHANDLED REJECTION '+String(e&&e.stack||e));diag.add('error','UNHANDLED_REJECTION',e);diag.flush(app?app.report():{},true);});
 process.on('uncaughtException',e=>{bootLog('UNCAUGHT EXCEPTION '+String(e&&e.stack||e));if(app)app.telemetry.pause();diag.add('error','UNCAUGHT_EXCEPTION',e);diag.flush(app?app.report():{},true);});
 const logging=require('oap-sdk/src/logging/logging');
 diag.sink=logging.getSDKLogger();
 const someip=require('oap-sdk/src/someip/someipBuilders');
 const createHost=require('./online-host.js').createHost;
 diag.step('SDK_LOADED');
 app=require(path.join(ROOT,'lib','app-runtime.js')).start({root:ROOT,data:DATA,config:config,diag:diag,someip:someip,createHost:createHost});
 bootLog('HOST start requested for '+config.id+' '+config.version);
}catch(e){bootLog('BOOT_FAILED '+String(e&&e.stack||e));if(diag){diag.add('error','BOOT_FAILED',e);diag.flush({},true);}}
