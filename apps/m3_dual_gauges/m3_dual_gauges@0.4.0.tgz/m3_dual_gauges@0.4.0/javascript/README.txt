The head unit creates app.js and its donor-compatible runner.js from this source package. No BMW SDK is bundled.
