'use strict';
/* Font adapter, not a redistributed font. Reads already-installed head-unit atlases when available.
 * No BMW/OS font or pre-baked atlas is shipped in this package. The final fallback is drawn procedurally.
 * Public interface matches the MIT reference kit/fonts.js. Original LICENSE/NOTICE/SOURCE retained.
 */
const fs=require('fs'),path=require('path'),zlib=require('zlib');
const caches={},dirs=[];
function discover(){if(dirs.length)return;dirs.push(path.join(__dirname,'fonts'));
 try{fs.readdirSync('/var/opt/public/oap').filter(n=>/^oap_\d+$/.test(n)).forEach(n=>{const base='/var/opt/public/oap/'+n+'/source';try{const p=JSON.parse(fs.readFileSync(base+'/package.json','utf8'));if(p.name==='iteriodev_cardash'||p.name==='robertn_store')dirs.push(base+'/renderer/kit/fonts');}catch(e){}});}catch(e){}
}
// Original procedural 5x7 technical lettering; generated directly into memory, not loaded from a font file.
const GRID={
 'A':['01110','10001','10001','11111','10001','10001','10001'],'B':['11110','10001','10001','11110','10001','10001','11110'],'C':['01111','10000','10000','10000','10000','10000','01111'],
 'D':['11110','10001','10001','10001','10001','10001','11110'],'E':['11111','10000','10000','11110','10000','10000','11111'],'F':['11111','10000','10000','11110','10000','10000','10000'],
 'G':['01111','10000','10000','10111','10001','10001','01111'],'H':['10001','10001','10001','11111','10001','10001','10001'],'I':['111','010','010','010','010','010','111'],
 'J':['00111','00010','00010','00010','10010','10010','01100'],'K':['10001','10010','10100','11000','10100','10010','10001'],'L':['10000','10000','10000','10000','10000','10000','11111'],
 'M':['10001','11011','10101','10101','10001','10001','10001'],'N':['10001','11001','11001','10101','10011','10011','10001'],'O':['01110','10001','10001','10001','10001','10001','01110'],
 'P':['11110','10001','10001','11110','10000','10000','10000'],'Q':['01110','10001','10001','10001','10101','10010','01101'],'R':['11110','10001','10001','11110','10100','10010','10001'],
 'S':['01111','10000','10000','01110','00001','00001','11110'],'T':['11111','00100','00100','00100','00100','00100','00100'],'U':['10001','10001','10001','10001','10001','10001','01110'],
 'V':['10001','10001','10001','10001','10001','01010','00100'],'W':['10001','10001','10001','10101','10101','11011','10001'],'X':['10001','10001','01010','00100','01010','10001','10001'],
 'Y':['10001','10001','01010','00100','00100','00100','00100'],'Z':['11111','00001','00010','00100','01000','10000','11111'],
 '0':['01110','10001','10011','10101','11001','10001','01110'],'1':['010','110','010','010','010','010','111'],'2':['01110','10001','00001','00010','00100','01000','11111'],
 '3':['11110','00001','00001','01110','00001','00001','11110'],'4':['00010','00110','01010','10010','11111','00010','00010'],'5':['11111','10000','10000','11110','00001','00001','11110'],
 '6':['01110','10000','10000','11110','10001','10001','01110'],'7':['11111','00001','00010','00100','01000','01000','01000'],'8':['01110','10001','10001','01110','10001','10001','01110'],'9':['01110','10001','10001','01111','00001','00001','01110'],
 '?':['01110','10001','00001','00010','00100','00000','00100'],'!':['1','1','1','1','1','0','1'],'.':['0','0','0','0','0','1','1'],',':['00','00','00','00','00','01','10'],':':['0','1','1','0','1','1','0'],
 '-':['000','000','000','111','000','000','000'],'_':['00000','00000','00000','00000','00000','00000','11111'],'+':['000','010','010','111','010','010','000'],
 '/':['00001','00001','00010','00100','01000','10000','10000'],'\\':['10000','10000','01000','00100','00010','00001','00001'],
 '(' :['001','010','100','100','100','010','001'],')':['100','010','001','001','001','010','100'],'[':['111','100','100','100','100','100','111'],']':['111','001','001','001','001','001','111'],
 '=':['00000','00000','11111','00000','11111','00000','00000'],'%':['11001','11010','00100','01000','10110','00110','00000'],'|':['1','1','1','1','1','1','1'],
 '"':['101','101','000','000','000','000','000'],"'":['1','1','0','0','0','0','0'],'<':['001','010','100','010','001','000','000'],'>':['100','010','001','010','100','000','000'],
 '#':['01010','11111','01010','01010','11111','01010','00000'],'*':['00000','10101','01110','11111','01110','10101','00000']};
function procedural(size){const unit=Math.max(1,Math.round(size/9)),cellW=7*unit,cellH=10*unit,aw=cellW*16,ah=cellH*6,alpha=Buffer.alloc(aw*ah),glyphs={};
 for(let code=32;code<128;code++){const ch=String.fromCharCode(code),r=GRID[ch]||GRID[ch.toUpperCase()]||GRID['?'],i=code-32,x=(i%16)*cellW,y=Math.floor(i/16)*cellH,w=r[0].length*unit,h=7*unit;glyphs[code]=ch===' '?[x,y,0,0,0,0,3*unit]:[x,y,w,h,0,-h,(r[0].length+1.3)*unit];if(ch===' ')continue;
  for(let yy=0;yy<7;yy++)for(let xx=0;xx<r[yy].length;xx++)if(r[yy][xx]==='1')for(let dy=0;dy<unit;dy++)for(let dx=0;dx<unit;dx++)alpha[(y+yy*unit+dy)*aw+x+xx*unit+dx]=255;
 }
 return {size:unit*9,ascent:unit*8,descent:unit,atlasW:aw,atlasH:ah,glyphs:glyphs,alpha:alpha};
}
function get(name,size){discover();const id=name+':'+Math.ceil(size/8)*8;if(caches[id])return caches[id];for(const dir of dirs){try{const j=JSON.parse(fs.readFileSync(path.join(dir,name+'.json'),'utf8'));if(!j.sizes||!j.sizes.length)continue;let best=j.sizes.filter(s=>s.size>=size).sort((a,b)=>a.size-b.size)[0]||j.sizes[j.sizes.length-1];const f={size:best.size,ascent:best.ascent,descent:best.descent,atlasW:best.atlasW,atlasH:best.atlasH,glyphs:best.glyphs,alpha:zlib.inflateSync(Buffer.from(best.alpha,'base64'))};return caches[id]=f;}catch(e){}}
 return caches[id]=procedural(Math.max(18,Math.min(180,Math.ceil(size/8)*8)));
}
function measure(f,s){let w=0;for(const ch of String(s)){const g=f.glyphs[ch.codePointAt(0)]||f.glyphs[63];if(g)w+=g[6];}return w;}
module.exports={get:get,measure:measure};
