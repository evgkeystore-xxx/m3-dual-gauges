'use strict';
/* M3 M CONTROL - authored cockpit UI for the user's 2880×960 iDrive 8 renderer.
 * Native HMI has exclusive top 0..75 and climate 840..959. All controls and
 * hit targets are in renderer logical coordinates, not CSS/browser coordinates.
 */
const Recorder=require('../kit/record').Recorder;
const C={ink:'#03070e',deep:'#071120',navy:'#0a1b32',panel:'#0d1e35',edge:'#315073',white:'#f6f8ff',muted:'#abb9cc',sub:'#7b8eaa',red:'#ff2454',scarlet:'#fb4b6f',blue:'#26a8ff',ice:'#66dbff',purple:'#ad69ff',green:'#41eeb3',yellow:'#ffbd59'};
const THEMES=[['M PERFORMANCE','#ff2454','needle'],['M BLUE','#30b8ff','ring'],['NIGHT PURPLE','#a566ff','needle'],['TRACK RED','#ff5a43','bar'],['NIGHT DRIVE','#8399bc','ring'],['M COMPETITION','#ff315b','needle'],['ICE BLUE','#61ddff','ring'],['GOLD EDITION','#ffbf5e','bar'],['STEALTH','#bdcbe5','digital'],['RACE DAY','#ff8842','needle'],['TOURING','#45ecb1','ring'],['M BLACK','#a5aec5','digital']];
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const fmt=(n,d)=>typeof n==='number'&&Number.isFinite(n)?n.toFixed(d||0):'--';
function wrap(s,n){const out=[];String(s).split('\n').forEach(line=>{while(line.length>n){let p=line.lastIndexOf(' ',n);if(p<n*.5)p=n;out.push(line.slice(0,p));line=line.slice(p).trim();}out.push(line);});return out;}
class View{
 constructor(config){this.config=config;this.buttons=[];this.sliders=[];this.model=null;}
 text(r,s,x,y,size,color,align){return r.text(String(s),x,y+size*.85,size,color||C.white,{align:align||'left',font:'m3suite-raster-v1'});}
 stroke(r,x,y,w,h,c){r.strokeRoundRect(x,y,w,h,16,2,c||C.edge);}
 backdrop(r){r.clear([0,0,0,0]);r.gradientRect(0,76,2880,764,[[0,'#040916'],[.3,'#09182b'],[.68,'#081222'],[1,'#040811']]);
  r.quad([[0,79],[810,79],[490,838],[0,838]],'#071a35');r.quad([[720,79],[1430,79],[1060,838],[470,838]],'#091b33');r.quad([[2020,79],[2460,79],[2090,838],[1730,838]],'#091a30');
  r.line(415,835,1040,80,3,'#183756');r.line(1860,836,2180,80,3,'#14314e');
  r.gradientRect(0,77,2880,4,[[0,'#0e59a9'],[.3,C.blue],[.55,C.red],[1,'#253974']]);
  r.gradientRect(0,836,2880,3,[[0,'#0d3760'],[.4,C.blue],[.75,C.red],[1,'#0e326b']]);}
 plate(r,x,y,w,h,c){r.card(x,y,w,h,20,[[0,'#122947'],[.36,'#0a1a31'],[1,'#071220']]);r.strokeRoundRect(x,y,w,h,20,2,c||'#244364');r.roundRect(x+20,y+10,w-40,3,2,c||'#27537c');}
 button(r,id,label,x,y,w,h,active,disabled,accent){const c=accent||C.blue;
  r.card(x,y,w,h,14,active?[[0,'#6a2448'],[.48,c],[1,'#4b162f']]:[[0,'#17314f'],[.44,'#0b2038'],[1,'#091321']]);
  r.strokeRoundRect(x,y,w,h,14,active?4:2,active?'#f6aabe':disabled?'#26334a':'#37628a');
  if(active)r.roundRect(x+14,y+h-8,w-28,4,2,'#ffd3df');else r.roundRect(x+13,y+7,w-26,2,1,'#2b6089');
  this.text(r,label,x+w/2,y+(h-30)/2,Math.min(31,h*.49),disabled?'#73839d':C.white,'center');
  if(id&&!disabled)this.buttons.push({id,x,y,w,h,kind:'button'});
 }
 sectionLabel(r,label,x,y,w,accent){this.text(r,label,x,y,29,C.muted);r.line(x,y+37,x+w,y+37,2,accent||'#264768');}
 header(r,m){
  r.gradientRect(0,82,2880,83,[[0,'#061327'],[.43,'#12335e'],[.67,'#0e2040'],[1,'#081226']]);
  r.quad([[1630,83],[1900,83],[1840,163],[1570,163]],'#113968');r.quad([[1960,83],[2020,83],[1960,163],[1900,163]],'#4e1955');
  [C.blue,'#8495ff',C.red].forEach((c,i)=>r.quad([[46+i*24,103],[64+i*24,103],[48+i*24,145],[30+i*24,145]],c));
  this.text(r,'M',120,104,50,C.white);this.text(r,'CONTROL',170,114,35,C.white);r.line(454,104,454,150,2,'#5f7297');
  this.text(r,this.config.kind==='pops'?'Pops Studio':this.config.kind==='cockpit'?'Cockpit Studio':'Dual Gauges',484,113,34,'#d0dcf0');
  this.text(r,'M3 G80',2255,114,29,C.white);const online=m.frame.hasReal&&!m.frame.demo;r.circle(2480,132,10,m.frame.demo?C.yellow:online?C.green:C.red);
  this.text(r,m.frame.demo?'DEMO':online?'DANE LIVE':'BRAK DANYCH',2506,114,29,m.frame.demo?C.yellow:online?C.green:C.red);
 }

 tabs(r,m){
  // No bottom in-app tabs: navigation is inside Settings as requested.
  if(this.config.kind==='pops')return;
  this.button(r,'page:home','ZEGARY',55,178,625,65,m.page==='home',false,C.red);
  this.button(r,'page:themes','MOTYWY',692,178,625,65,m.page==='themes',false,C.purple);
  this.button(r,'page:params','LIVE',1330,178,450,65,m.page==='params',false,C.blue);
  this.button(r,'page:settings','USTAWIENIA',2330,178,495,65,m.page==='settings',false,C.blue);
 }

 status(r,m){const f=m.frame,online=f.hasReal&&!f.demo,color=f.demo?C.yellow:online?C.green:C.red;
  r.card(55,789,2770,44,10,[[0,'#09243e'],[.35,'#081b32'],[1,'#0d1b31']]);r.strokeRoundRect(55,789,2770,44,10,2,'#2872a5');
  r.circle(81,812,9,color);const label=(f.demo?'DEMO':online?'LIVE':'OFFLINE')+'  |  RPM '+fmt(f.values.rpm)+'  |  KM/H '+fmt(f.values.speed);
  this.text(r,label,107,794,25,color);this.text(r,'ECU SILNIKA  -  TYLKO ODCZYT',2080,797,22,C.muted);
  this.text(r,'BLEDY: '+(m.errors||0),2760,794,24,(m.errors||0)?C.yellow:C.green,'right');
  this.buttons.push({id:'page:settings',kind:'button',x:55,y:789,w:2770,h:44});
 }

 draw(m){this.model=m;this.buttons=[];this.sliders=[];const r=new Recorder(2880,960,{textScale:1});this.backdrop(r);r.clip(0,76,2880,764);this.header(r,m);
  if(this.config.kind==='pops'){
    this.popsNav(r,m);
    if(m.page==='settings'){if(m.settingsScroll)this.popsSettingsExtra(r,m);else this.popsSettings(r,m);this.scrollIndicator(r,m);}
    else if(m.page==='errors')this.popsErrors(r,m);
    else if(m.page==='camera')this.popsCamera(r,m);
    else if(m.page==='advanced')this.settings(r,m);
    else if(m.page==='params')this.params(r,m);
    else if(m.page==='graphs')this.graphs(r,m);
    else if(m.page==='exhaust')this.exhaust(r,m);
    else this.pops(r,m);
  }else{
    this.tabs(r,m);
    if(m.page==='errors')this.errors(r,m);else if(m.page==='settings')this.settings(r,m);else if(m.page==='themes')this.themes(r,m);else if(m.page==='graphs')this.graphs(r,m);else if(m.page==='params')this.params(r,m);else if(m.page==='engine')this.engine(r,m);else this.gauges(r,m);
  }
  if(m.notice){r.card(550,738,1770,43,10,[[0,'#57344d'],[1,'#231b34']]);this.text(r,String(m.notice).slice(0,100),570,744,26,C.yellow);}
  this.status(r,m);r.noclip();return r;
 }

 hitTarget(x,y){for(let i=this.sliders.length-1;i>=0;i--){const a=this.sliders[i];if(x>=a.x&&x<=a.x+a.w&&y>=a.y&&y<=a.y+a.h)return a;}for(let i=this.buttons.length-1;i>=0;i--){const a=this.buttons[i];if(x>=a.x&&x<=a.x+a.w&&y>=a.y&&y<=a.y+a.h)return a;}return null;}
 hit(x,y){const t=this.hitTarget(x,y);return t?t.id:null;}
 slider(r,id,title,val,min,max,step,x,y,w,accent,disabled,unit){const c=accent||C.red;
  this.text(r,title,x,y-47,26,C.muted);this.text(r,fmt(val,step<1?1:0)+(unit||''),x+w,y-46,29,C.white,'right');
  r.roundRect(x,y+21,w,12,6,'#284058');r.gradientRect(x,y+21,w,12,[[0,C.green],[.43,C.yellow],[.83,C.red],[1,'#dc315a']]);
  const p=clamp((val-min)/(max-min),0,1);r.circle(x+p*w,y+27,19,'#f5f8ff');r.circle(x+p*w,y+27,13,disabled?'#8090a7':c);
  this.text(r,String(min),x,y+48,20,C.sub);this.text(r,String(max),x+w,y+48,20,C.sub,'right');
  if(!disabled)this.sliders.push({kind:'slider',id,x,y:y-14,w,h:92,min,max,step});}
 range(r,a,b,x,y,w){this.text(r,'AKTYWACJA OBROTOW',x,y-44,26,C.muted);this.text(r,a+' - '+b+' RPM',x+w,y-44,30,C.white,'right');r.roundRect(x,y+20,w,13,6,'#1f354e');r.gradientRect(x,y+20,w,13,[[0,C.green],[.5,C.yellow],[1,C.red]]);
  [a,b].forEach((val,i)=>{const xx=x+w*clamp((val-1000)/6600,0,1);r.circle(xx,y+27,19,C.white);r.circle(xx,y+27,12,i?C.red:C.blue);});this.text(r,'1000',x,y+49,20,C.sub);this.text(r,'7600',x+w,y+49,20,C.sub,'right');this.sliders.push({kind:'range',id:'range:rpm',x,y:y-10,w,h:94,min:1000,max:7600,step:100});}
 telemetry(r,m){const v=m.frame.values;this.glass(r,2110,273,714,476,C.blue);this.text(r,'PARAMETRY LIVE',2150,297,33,C.white);
  const rows=[['AKTUALNA MOC',fmt(v.powerHp),'KM'],['OBROTY SILNIKA',fmt(v.rpm),'RPM'],['DOLADOWANIE',fmt(v.boost,2),'bar'],['MOMENT',fmt(v.torque),'Nm'],['TEMP. OLEJU',fmt(v.oil),'C'],['PLYN CHLODZACY',fmt(v.coolant),'C']];
  rows.forEach((a,i)=>{const y=355+i*61;r.line(2150,y-8,2785,y-8,1,'#2b537b');r.roundRect(2151,y+9,5,35,3,i%2?C.red:C.blue);this.text(r,a[0],2177,y+6,23,C.muted);this.text(r,a[1]+' '+a[2],2785,y+3,31,C.white,'right');});
 }
 glass(r,x,y,w,h,c){r.card(x,y,w,h,20,[[0,'#12345b'],[.16,'#0b2342'],[.7,'#06162b'],[1,'#071226']]);r.strokeRoundRect(x,y,w,h,20,3,c||C.blue);r.roundRect(x+20,y+12,w-40,4,2,c||C.blue);}
 popsNav(r,m){const mode=m.settings.mode,items=[['comfort','COMFORT','C'],['sport','SPORT','S'],['sportplus','SPORT+','M'],['pn','P / N','N']];
  items.forEach((a,i)=>{const x=56+i*505;this.button(r,'mode:'+a[0],a[2]+'   '+a[1],x,182,488,68,mode===a[0]&&m.page==='home',false,mode===a[0]?C.red:C.blue);});
  this.button(r,'page:camera','[ ]  KAMERA',2083,182,348,68,m.page==='camera',false,C.blue);
  this.button(r,'page:settings','*  USTAWIENIA',2450,182,374,68,m.page==='settings',false,m.page==='settings'?C.red:C.blue);
 }

 pops(r,m){const s=m.settings,p=s.profile[s.mode];
  this.glass(r,55,273,1325,476,C.blue);this.text(r,'M  PROFIL '+(s.mode==='sportplus'?'SPORT+':s.mode==='pn'?'P / N':s.mode.toUpperCase())+'  /  USTAWIENIA LOKALNE',92,299,32,C.white);
  this.text(r,'PROFIL DEMO - BRAK ZAPISU W ECU',92,348,23,C.muted);
  this.range(r,p.rpmMin,p.rpmMax,110,432,1212);
  this.slider(r,'profile:duration','DLUGOSC',p.duration,0,4,.1,112,574,365,C.red,s.mode==='comfort',' s');
  this.slider(r,'profile:aggression','MOC',p.aggression,0,100,5,544,574,365,C.red,s.mode==='comfort',' %');
  this.slider(r,'profile:delay','OPOZNIENIE',p.delay||0,0,1000,25,970,574,350,C.red,s.mode==='comfort',' ms');
  this.glass(r,1400,273,686,476,C.purple);this.text(r,'FLAME MODE',1435,304,39,C.white);
  this.text(r,'TYLKO PODGLAD - BRAK API ECU',1434,354,24,C.muted);
  this.button(r,null,'M   SPORT+',1435,425,614,70,false,true,C.purple);
  this.button(r,null,'P / N',1435,519,614,70,false,true,C.purple);
  this.text(r,'ECU SILNIKA - TYLKO ODCZYT',1433,680,25,C.ice);
  this.telemetry(r,m);
 }
 popsSettings(r,m){
  this.glass(r,55,273,943,296,C.blue);this.text(r,'POLACZENIE',89,298,39,C.white);
  const t=[['RENDERER MGU',m.touchSupported?'POLACZONO':'SPRAWDZ'],['DOTYK',m.touchSupported?'AKTYWNY':'BRAK SYGNALU'],['DANE LIVE',m.frame.hasReal?'ODBIERANE':'NIEDOSTEPNE']];
  t.forEach((a,i)=>{const y=366+i*59;r.circle(100,y+12,10,a[1]==='SPRAWDZ'||a[1]==='NIEDOSTEPNE'||a[1]==='BRAK SYGNALU'?C.yellow:C.green);this.text(r,a[0],130,y-3,29,C.white);this.text(r,a[1],934,y-3,27,C.muted,'right');});
  this.glass(r,1018,273,1070,296,C.purple);this.text(r,'DIAGNOSTYKA I DEBUG',1050,298,36,C.white);
  this.button(r,'page:errors','OTWORZ ZAAWANSOWANE LOGI   >',1050,361,1000,67,false,false,C.purple);
  this.text(r,'BLEDY: '+m.errors+'  |  ZDARZENIA DOTYKU: '+m.touchEvents,1050,450,28,C.muted);
  this.text(r,'STATUS RHMI: '+(m.touchSupported?'GOTOWY':'DO SPRAWDZENIA'),1050,502,25,C.ice);
  this.glass(r,2110,273,714,296,C.blue);this.text(r,'KAMERA',2148,298,38,C.white);
  this.text(r,'OEM: NIEPODLACZONA',2148,371,30,C.yellow);
  this.button(r,'page:camera','TEST / SZCZEGOLY',2148,433,634,73,false,false,C.blue);
  this.glass(r,55,582,1210,174,C.blue);this.text(r,'INTERFEJS',89,603,36,C.white);
  this.button(r,'page:graphs','WYKRESY',90,663,322,63,false,false,C.blue);this.button(r,'page:params','LIVE / PARAMETRY',430,663,385,63,false,false,C.blue);
  this.button(r,'backup','KOPIA USTAWIEN',834,663,390,63,false,false,C.blue);
  this.glass(r,1283,582,800,174,C.purple);this.text(r,'ECU SILNIKA',1319,607,35,C.white);
  this.text(r,'TYLKO ODCZYT',1319,669,31,C.ice);
  this.glass(r,2108,582,716,174,C.blue);this.text(r,'DODATKOWE',2144,605,33,C.white);
  this.button(r,'page:exhaust','KLAPA / ORYGINALNE',2144,652,307,65,false,false,C.blue);
  this.button(r,'page:advanced','WIECEJ',2463,652,317,65,false,false,C.blue);
 }
 popsErrors(r,m){this.glass(r,55,273,2770,483,C.purple);const lines=wrap(m.errorText||'BRAK ZAPISANYCH BLEDOW',147),per=10,max=Math.max(1,Math.ceil(lines.length/per)),page=clamp(m.errorPage,0,max-1);
  this.text(r,'ZAAWANSOWANA DIAGNOSTYKA / '+(page+1)+' / '+max,93,294,35,C.white);
  lines.slice(page*per,(page+1)*per).forEach((t,i)=>this.text(r,t,95,347+i*29,23,i===0?C.yellow:C.muted));
  this.button(r,'error:prev','POPRZEDNIA',91,673,485,65,false,page===0,C.blue);this.button(r,'error:next','NASTEPNA',590,673,485,65,false,page>=max-1,C.blue);this.button(r,'error:refresh','ODSWIEZ',1089,673,485,65,false,false,C.blue);this.button(r,'retry','POLACZ PONOWNIE',1587,673,620,65,false,false,C.red);this.button(r,'page:settings','<  USTAWIENIA',2230,673,556,65,false,false,C.blue);
 }
 popsCamera(r,m){this.glass(r,55,273,2770,483,C.blue);this.text(r,'KAMERA / STATUS INTEGRACJI',105,310,44,C.white);
  this.text(r,'BRAK OBSLUGIWANEGO INTERFEJSU OBRAZU OEM W AKTUALNYM PAKIECIE',105,402,36,C.yellow);
  this.text(r,'NIE WYSWIETLAMY SYMULOWANEGO PODGLADU JAKO AKTYWNEJ KAMERY.',105,475,29,C.muted);
  this.button(r,'page:settings','USTAWIENIA I DIAGNOSTYKA',105,619,1160,90,false,false,C.blue);
 }

 dial(r,x,y,R,val,max,label,unit,accent){const valid=typeof val==='number'&&Number.isFinite(val),p=valid?clamp(val/max,0,1):0;
  r.arc(x,y,R-14,R,230,490,'#26466d');r.arc(x,y,R-12,R+5,230,230+260*p,accent,{round:true});r.arc(x,y,R-12,R+5,455,490,C.red);
  for(let i=0;i<=16;i++){const a=(230+260*i/16)*Math.PI/180;r.line(x+Math.sin(a)*(R-22),y-Math.cos(a)*(R-22),x+Math.sin(a)*(R-42),y-Math.cos(a)*(R-42),i%4===0?4:2,i>13?C.red:C.muted);}
  const a=(230+260*p)*Math.PI/180;r.line(x,y,x+Math.sin(a)*(R-62),y-Math.cos(a)*(R-62),7,accent);r.circle(x,y,18,accent);r.circle(x,y,9,C.white);
  this.text(r,fmt(val),x,y+52,89,C.white,'center');this.text(r,unit,x,y+153,24,C.muted,'center');this.text(r,label,x,y+R+18,32,C.white,'center');}
 gauges(r,m){const v=m.frame.values,t=THEMES[m.settings.theme]||THEMES[0];this.plate(r,55,265,2770,468,t[1]);
  this.text(r,this.config.kind==='cockpit'?'M3 COMPETITION / COCKPIT STUDIO':'M3 COMPETITION / DUAL GAUGES',92,291,36,C.white);this.text(r,t[0],2790,293,29,t[1],'right');
  this.dial(r,690,500,158,v.rpm,8000,'OBROTY SILNIKA','RPM',t[1]);this.dial(r,2195,500,158,v.speed,340,'PREDKOSC','km/h',C.ice);
  this.plate(r,1110,351,645,304,C.blue);this.text(r,'M3',1432,379,60,C.white,'center');this.text(r,'COMPETITION',1432,444,38,C.white,'center');
  this.text(r,fmt(v.powerHp),1432,492,76,C.ice,'center');this.text(r,'KM / MOC OBLICZONA',1432,576,24,C.muted,'center');
  this.button(r,'theme:prev','<',1150,663,120,56,false,false,C.blue);this.button(r,'page:themes','12 MOTYWOW',1280,663,400,56,false,false,t[1]);this.button(r,'theme:next','>',1690,663,120,56,false,false,C.blue);
 }
 mini(r,label,value,unit,x,y,w,h,color){this.plate(r,x,y,w,h,color);this.text(r,label,x+29,y+22,28,C.muted);this.text(r,value,x+w-36,y+69,72,C.white,'right');this.text(r,unit,x+30,y+h-52,27,C.sub);}
 params(r,m){const v=m.frame.values,rows=[['OBROTY',fmt(v.rpm),'RPM'],['PREDKOSC',fmt(v.speed),'KM/H'],['MOC OBLICZONA',fmt(v.powerHp),'KM'],['MOMENT',fmt(v.torque),'NM'],['DOLADOWANIE',fmt(v.boost,2),'BAR'],['TEMP. OLEJU',fmt(v.oil),' C'],['CHLODZENIE',fmt(v.coolant),' C'],['ZAPLON',fmt(v.timing,1),' DEG']];
  rows.forEach((a,i)=>this.mini(r,a[0],a[1],a[2],55+i%4*699,264+Math.floor(i/4)*239,674,218,i%2?C.red:C.blue));}
 graphs(r,m){this.plate(r,55,265,2770,469,C.blue);this.text(r,'WYKRES OBROTOW / 60 SEKUND',100,296,38,C.white);this.button(r,'graph:toggle',m.recording?'STOP':'START',2470,289,311,70,m.recording,false,C.red);
  const x=180,y=402,w=2460,h=243;for(let i=0;i<5;i++){const yy=y+i*h/4;r.line(x,yy,x+w,yy,1,'#2a496c');this.text(r,String(8000-i*2000),x-23,yy-17,24,C.muted,'right');}
  let prev=null;m.history.filter(a=>m.at-a.at<=60000).forEach(p=>{const xx=x+w-(m.at-p.at)/60000*w,yy=y+h-clamp(p.rpm/8000,0,1)*h;if(prev)r.line(prev[0],prev[1],xx,yy,5,C.red);prev=[xx,yy];});this.text(r,'-60 S',x,678,26,C.muted);this.text(r,'TERAZ',x+w,678,26,C.muted,'right');
  this.text(r,m.frame.demo?'DEMO / SYMULACJA':m.frame.hasReal?'DANE Z SAMOCHODU':'BRAK ODCZYTOW',100,704,25,m.frame.demo?C.yellow:C.green);}
 themes(r,m){this.text(r,'WYBIERZ STYL M PERFORMANCE',83,269,35,C.white);THEMES.forEach((a,i)=>{const x=55+i%6*463,y=315+Math.floor(i/6)*200;this.button(r,'theme:'+i,a[0],x,y,443,157,m.settings.theme===i,false,a[1]);r.roundRect(x+24,y+130,392,7,3,a[1]);});}
 engine(r,m){const v=m.frame.values,rows=[['MOC / SKALA '+m.settings.maxPower+' KM',v.powerHp,m.settings.maxPower,'KM',C.red],['MOMENT',v.torque,1000,'NM',C.blue],['DOLADOWANIE',v.boost,3,'BAR',C.purple]];rows.forEach((a,i)=>{const y=263+i*157;this.plate(r,55,y,2770,142,a[4]);this.text(r,a[0],90,y+20,32,C.muted);this.text(r,fmt(a[1],a[3]==='BAR'?2:0)+' '+a[3],2780,y+15,53,C.white,'right');r.roundRect(88,y+105,2670,16,8,'#263c58');if(typeof a[1]==='number')r.roundRect(88,y+105,2670*clamp(a[1]/a[2],0,1),16,8,a[4]);});}
 exhaust(r,m){const f=m.flap;this.plate(r,55,265,1672,468,C.red);this.text(r,'KLAPA WYDECHU / MHD',91,297,43,C.white);this.text(r,'ODREBNA FUNKCJA OD POPS / BURBLE',91,366,29,C.muted);this.text(r,'POZYCJA: '+(m.at-f.at<6000?fmt(f.pct,1)+' %':'--'),91,423,44,C.ice);
  this.button(r,'flap:open','OTWORZ',94,545,498,93,false,m.busy,C.red);this.button(r,'flap:close','ZAMKNIJ',618,545,500,93,false,m.busy,C.red);this.button(r,'flap:oem','ORYGINALNE',1144,545,527,93,false,m.busy,C.blue);
  this.text(r,'POTWIERDZENIE: DWUKROTNE DOTKNIECIE / TYLKO NA POSTOJU',94,682,24,C.yellow);
  this.plate(r,1745,265,1080,468,C.blue);this.text(r,'JEDNA MAPA MHD / 700 KM',1780,304,37,C.white);this.text(r,'BRAK FLASH / BRAK MULTIMAP',1780,380,30,C.green);this.text(r,'ORYGINALNE ODDAJE KLAPE DME',1780,445,27,C.muted);this.text(r,'NIE PRZYWRACA MAPY FABRYCZNEJ',1780,494,27,C.muted);this.text(r,'BRAK API POPS MHD',1780,581,28,C.yellow);}
 settings(r,m){this.plate(r,55,265,2770,469,C.blue);this.text(r,'USTAWIENIA I BEZPIECZENSTWO',95,299,42,C.white);this.text(r,'TWOJA MAPA MHD 700 KM NIE JEST MODYFIKOWANA',95,365,29,C.green);
  this.button(r,'backup','KOPIA USTAWIEN',95,449,625,82,false,false,C.blue);this.button(r,'restore','PRZYWROC USTAWIENIA',745,449,695,82,false,false,C.blue);this.button(r,'autoDemo','AUTO DEMO: '+(m.settings.autoDemo?'ON':'OFF'),1465,449,605,82,m.settings.autoDemo,false,C.red);this.button(r,'retry','PONOW ODCZYT',2097,449,685,82,false,false,C.blue);
  this.button(r,'flash','SHIFT LED: '+(m.settings.flash?'ON':'OFF'),96,571,626,77,m.settings.flash,false,C.red);this.text(r,'KOPIA DOTYCZY USTAWIEN APLIKACJI - NIE ECU',760,588,30,C.yellow);this.text(r,'DIAGNOSTYKA: '+(m.phoneUrl||'HTTP://IP-MGU:8471').toUpperCase(),95,678,26,C.ice);}
 errors(r,m){this.plate(r,55,265,2770,469,C.red);const lines=wrap(m.errorText||'BRAK ZAPISANYCH BLEDOW',140),per=10,max=Math.max(1,Math.ceil(lines.length/per)),page=clamp(m.errorPage,0,max-1);this.text(r,'DIAGNOSTYKA / '+(page+1)+' / '+max,96,299,36,C.white);
  lines.slice(page*per,(page+1)*per).forEach((s,i)=>this.text(r,s,100,353+i*28,22,i===0?C.yellow:C.muted));
  this.button(r,'error:prev','POPRZEDNIA',95,661,500,62,false,page===0,C.blue);this.button(r,'error:next','NASTEPNA',610,661,500,62,false,page>=max-1,C.blue);this.button(r,'error:refresh','ODSWIEZ',1125,661,500,62,false,false,C.blue);this.button(r,'retry','POLACZ PONOWNIE',1642,661,1139,62,false,false,C.red);}
}

// --- M CONTROL PREMIUM VISUAL LAYER, VERSION 1.7 ---
// Keep Controller and renderer event handling from the proven 1.6 baseline.
const ART=require('./artwork');
const blueRamp=[[0,'#061325'],[.18,'#123456'],[.44,'#0b2548'],[.72,'#07172f'],[1,'#061024']];
const redRamp=[[0,'#531b39'],[.2,'#bf1444'],[.48,'#ff2255'],[.8,'#8b1743'],[1,'#230d25']];
const purpleRamp=[[0,'#17123c'],[.42,'#251752'],[.8,'#120e2b'],[1,'#0a0c1e']];
const hex=(n)=>Math.max(0,Math.min(255,n|0)).toString(16).padStart(2,'0');
View.prototype.icon=function(r,id,x,y,size){const im=ART.icon(id);if(im)r.image(im,x,y,size,size,Math.max(2,size*.16));};
View.prototype.neonPanel=function(r,x,y,w,h,accent,hero){
  const cyan=accent||C.blue,rd=hero?30:22;
  r.card(x-5,y-4,w+10,h+9,rd,[[0,'#051b34'],[.3,'#031125'],[1,'#030914']]);
  r.strokeRoundRect(x-5,y-4,w+10,h+9,rd,6,cyan+'28');
  r.card(x,y,w,h,rd,[[0,'#153b63'],[.16,'#102b4c'],[.47,'#0a1b35'],[.78,'#07162b'],[1,'#061124']]);
  r.strokeRoundRect(x,y,w,h,rd,hero?4:3,cyan);
  r.roundRect(x+21,y+12,w-42,5,2,cyan+'aa');
  r.roundRect(x+22,y+19,w-44,5,2,'#d8eaff24');
  r.quad([[x+w*.68,y+20],[x+w*.8,y+20],[x+w*.52,y+h-20],[x+w*.4,y+h-20]],'#ffffff07');
};
View.prototype.premiumButton=function(r,id,label,icon,x,y,w,h,active,disabled,accent){
 const c=accent||C.blue;
 if(active){r.card(x-5,y-5,w+10,h+10,18,[[0,c+'58'],[.5,c+'55'],[1,c+'20']]);r.strokeRoundRect(x-5,y-5,w+10,h+10,18,3,c);}else{r.roundRect(x-4,y-2,w+8,h+6,18,'#00000045');}
 r.card(x,y,w,h,15,active?redRamp:blueRamp);
 r.strokeRoundRect(x,y,w,h,15,active?4:2,active?'#ff789f':disabled?'#27425d':'#3a78ac');
 r.roundRect(x+17,y+10,w-34,3,2,active?'#fff0f4aa':'#9ad6ff66');
 if(icon)this.icon(r,icon,x+20,y+(h-65)/2,65);
 const size=icon?29:32;const xx=icon?x+82:x+w/2;
 if(icon)this.text(r,label,xx,y+(h-size)/2,size,disabled?'#6c829d':C.white);else this.text(r,label,xx,y+(h-size)/2,size,disabled?'#6c829d':C.white,'center');
 if(id&&!disabled)this.buttons.push({id,x,y,w,h,kind:'button'});
};
View.prototype.backdrop=function(r){
 r.clear([0,0,0,0]);r.gradientRect(0,76,2880,764,[[0,'#050b19'],[.25,'#061832'],[.62,'#08132b'],[1,'#030711']]);
 // refined blue carbon and M Motorsport diagonal geometry, no overlap with native top/climate bars
 for(let i=0;i<9;i++){const ox=i*460-170;r.quad([[ox,77],[ox+9,77],[ox-260,839],[ox-269,839]],'#75a8ff0c');}
 r.quad([[1570,78],[2125,78],[1610,837],[1040,837]],'#244c8218');
 r.quad([[2190,78],[2415,78],[1900,837],[1675,837]],'#b52b5414');
 r.gradientRect(0,77,2880,3,[[0,C.blue],[.3,'#28549c'],[.62,C.red],[1,C.blue]]);
 r.gradientRect(0,837,2880,3,[[0,'#246db4'],[.45,C.blue],[.77,C.red],[1,'#1d5bba']]);
};
View.prototype.header=function(r,m){
 r.card(28,88,2824,77,17,[[0,'#164370'],[.15,'#0e2b53'],[.64,'#0b1c3a'],[1,'#07162c']]);
 r.strokeRoundRect(28,88,2824,77,17,2,'#285d9b');
 r.quad([[1510,89],[1660,89],[1595,164],[1445,164]],'#1678d547');r.quad([[1668,89],[1735,89],[1670,164],[1603,164]],'#d5225947');
 this.icon(r,'m',55,94,64);this.text(r,'M',129,103,48,C.white);this.text(r,'CONTROL',184,112,37,C.white);
 r.line(455,104,455,149,2,'#a0b2cf77');this.text(r,this.config.kind==='pops'?'Pops Studio':this.config.kind==='cockpit'?'Cockpit Studio':'Dual Gauges',483,112,32,'#d7e4fb');
 this.text(r,'M3 G80',2240,116,29,'#e6f1ff');const live=m.frame.hasReal&&!m.frame.demo;const color=m.frame.demo?C.yellow:live?C.green:C.red;
 r.circle(2474,130,9,color);this.text(r,m.frame.demo?'DEMO':live?'DANE LIVE':'BRAK DANYCH',2501,114,28,color);
};
View.prototype.popsNav=function(r,m){
 const mode=m.settings.mode;const nav=[['comfort','Comfort','eco'],['sport','Sport','sport'],['sportplus','Sport+','m'],['pn','P / N','gear']];
 nav.forEach((a,i)=>this.premiumButton(r,'mode:'+a[0],a[1],a[2],48+i*485,184,470,76,mode===a[0]&&m.page==='home',false,mode===a[0]?C.red:C.blue));
 this.premiumButton(r,'page:camera','Kamera','camera',2012,184,386,76,m.page==='camera',false,C.blue);
 this.premiumButton(r,'page:settings','Ustawienia','settings',2416,184,420,76,m.page==='settings',false,C.red);
};
View.prototype.premiumRange=function(r,p,x,y,w){
 this.icon(r,'rpm',x,y-58,48);this.text(r,'AKTYWACJA OBROTÓW',x+60,y-47,28,'#d8e9fe');
 this.text(r,p.rpmMin+' - '+p.rpmMax+' RPM',x+w,y-45,30,C.white,'right');
 r.roundRect(x,y+26,w,13,7,'#17354f');
 r.rampRect(x,y+28,w,9,5,[[0,'#2193ef'],[.2,'#26eac1'],[.51,'#fbdb55'],[.77,'#ff873e'],[1,C.red]]);
 const ax=x+w*(p.rpmMin-1000)/6600,bx=x+w*(p.rpmMax-1000)/6600;
 r.roundRect(ax,y+27,Math.max(0,bx-ax),12,5,'#ff4e7488');
 [[ax,C.blue],[bx,C.red]].forEach(a=>{r.circle(a[0],y+33,21,'#eafaff');r.circle(a[0],y+33,14,a[1]);r.circle(a[0],y+33,6,'#f7ffff');});
 this.text(r,'1000',x,y+54,21,C.sub);this.text(r,'7600',x+w,y+54,21,C.sub,'right');
 this.sliders.push({kind:'range',id:'range:rpm',x,y:y-10,w,h:90,min:1000,max:7600,step:100});
};
View.prototype.premiumSlider=function(r,id,label,icon,value,min,max,step,x,y,w,unit,disabled){
 this.icon(r,icon,x,y-51,48);this.text(r,label,x+56,y-44,29,C.white);this.text(r,fmt(value,step<1?1:0)+(unit||''),x+w,y-45,31,C.white,'right');
 r.roundRect(x,y+16,w,14,7,'#243c5d');r.rampRect(x,y+19,w,9,4,[[0,'#1a98e8'],[.37,'#27cde7'],[.7,'#f33b68'],[1,'#ff204e']]);
 const p=clamp((value-min)/(max-min),0,1),pos=x+p*w;
 r.circle(pos,y+23,24,'#e7f7ff');r.circle(pos,y+23,16,disabled?'#8292ab':C.red);r.circle(pos,y+23,7,'#ffeaf2');
 this.text(r,String(min),x,y+53,19,C.sub);this.text(r,String(max),x+w,y+53,19,C.sub,'right');
 if(!disabled)this.sliders.push({kind:'slider',id,x,y:y-15,w,h:92,min,max,step});
};
View.prototype.telemetry=function(r,m){
 const x=2114,y=283,w=722,h=467;this.neonPanel(r,x,y,w,h,C.blue);this.icon(r,'wave',x+17,y+20,65);this.text(r,'PARAMETRY LIVE',x+94,y+35,34,C.white);
 const v=m.frame.values;const rows=[['AKTUALNA MOC',fmt(v.powerHp),'KM','power'],['OBROTY SILNIKA',fmt(v.rpm),'RPM','rpm'],['DOŁADOWANIE',fmt(v.boost,2),'bar','turbo'],['MOMENT',fmt(v.torque),'Nm','gear'],['TEMP. OLEJU',fmt(v.oil),'°C','engine'],['PŁYN CHŁODZĄCY',fmt(v.coolant),'°C','wave']];
 rows.forEach((a,i)=>{const ry=y+101+i*58;r.line(x+28,ry-8,x+w-25,ry-8,1,'#4d75975a');r.roundRect(x+24,ry+10,5,31,2,i%2?C.red:C.blue);this.icon(r,a[3],x+40,ry-8,51);this.text(r,a[0],x+102,ry+4,24,'#afc8e8');this.text(r,a[1]+' '+a[2],x+w-31,ry-1,31,'#f5f9ff','right');});
};
View.prototype.pops=function(r,m){const mode=m.settings.mode,p=m.settings.profile[mode];
 this.neonPanel(r,45,283,1354,467,C.blue,true);this.icon(r,'m',66,298,69);
 this.text(r,'PROFIL '+(mode==='sportplus'?'SPORT+':mode==='pn'?'P / N':mode.toUpperCase()),143,312,40,C.white);
 this.text(r,'USTAWIENIA LOKALNE',675,319,28,'#a9c9ec');r.line(79,371,1361,371,2,'#3376af80');
 this.text(r,'MHD POPS - BRAK POTWIERDZONEGO API ZAPISU',88,380,24,'#c3a8b4');
 this.premiumRange(r,p,89,468,1265);
 this.premiumSlider(r,'profile:duration','DŁUGOŚĆ','timer',p.duration,0,4,.1,100,624,367,' s',mode==='comfort');
 this.premiumSlider(r,'profile:aggression','MOC','power',p.aggression,0,100,5,562,624,354,' %',mode==='comfort');
 this.premiumSlider(r,'profile:delay','OPÓŹNIENIE','delay',p.delay,0,1000,25,1002,624,342,' ms',mode==='comfort');
 this.neonPanel(r,1420,283,672,467,C.purple);this.icon(r,'flame',1443,299,74);this.text(r,'FLAME MODE',1528,319,38,C.white);
 this.text(r,'TYLKO PODGLĄD - BRAK API ECU',1454,378,24,'#d2b6ef');
 this.premiumButton(r,null,'Sport+', 'm',1450,434,612,80,false,true,C.purple);
 this.premiumButton(r,null,'P / N', 'gear',1450,546,612,80,false,true,C.purple);
 this.icon(r,'shield',1450,663,58);this.text(r,'ECU SILNIKA / TYLKO ODCZYT',1518,680,26,'#76d9f9');
 this.telemetry(r,m);
};
View.prototype.popsSettings=function(r,m){
 this.neonPanel(r,45,283,882,295,C.blue);this.icon(r,'shield',68,298,73);this.text(r,'POŁĄCZENIE',150,318,37,C.white);
 const states=[['RENDERER MGU',m.touchSupported?'POŁĄCZONY':'NIEPOTWIERDZONY'],['DOTYK',m.touchSupported?'AKTYWNY':'BRAK ODCZYTU'],['DANE LIVE',m.frame.hasReal?'ODBIERANE':'NIEDOSTĘPNE']];
 states.forEach((a,i)=>{const yy=378+i*57;r.circle(100,yy+12,10,a[1]==='BRAK ODCZYTU'||a[1]==='NIEDOSTĘPNE'||a[1]==='NIEPOTWIERDZONY'?C.yellow:C.green);this.text(r,a[0],129,yy-2,28,C.white);this.text(r,a[1],903,yy-2,26,C.muted,'right');});
 this.neonPanel(r,949,283,1096,295,C.purple);this.icon(r,'logs',969,300,68);this.text(r,'DIAGNOSTYKA I DEBUG',1050,320,37,C.white);
 this.premiumButton(r,'page:errors','OTWÓRZ ZAAWANSOWANE LOGI','logs',979,380,1018,69,false,false,C.purple);
 this.text(r,'BŁĘDY '+m.errors+'     |     DOTYK '+m.touchEvents+'     |     RHMI '+(m.touchSupported?'GOTOWY':'NIEPOTWIERDZONY'),988,481,28,C.muted);
 this.neonPanel(r,2065,283,771,295,C.blue);this.icon(r,'camera',2094,300,70);this.text(r,'KAMERA',2175,320,37,C.white);
 this.text(r,'OEM: BRAK POTWIERDZONEGO API',2101,398,26,C.yellow);this.premiumButton(r,'page:camera','TEST / SZCZEGÓŁY','camera',2092,471,714,69,false,false,C.blue);
 this.neonPanel(r,45,601,1267,152,C.blue);this.icon(r,'settings',70,612,66);this.text(r,'INTERFEJS',148,625,35,C.white);
 this.premiumButton(r,'page:params','PARAMETRY','rpm',77,681,385,59,false,false,C.blue);this.premiumButton(r,'page:graphs','WYKRESY','wave',477,681,370,59,false,false,C.blue);this.premiumButton(r,'backup','KOPIA','shield',863,681,416,59,false,false,C.blue);
 this.neonPanel(r,1336,601,733,152,C.purple);this.icon(r,'engine',1353,611,76);this.text(r,'ECU SILNIKA',1450,627,35,C.white);this.text(r,'TYLKO ODCZYT',1453,687,31,C.ice);
 this.neonPanel(r,2091,601,745,152,C.blue);this.icon(r,'settings',2111,612,63);this.text(r,'INNE',2190,622,34,C.white);this.premiumButton(r,'retry','POŁĄCZ PONOWNIE','wave',2115,677,694,61,false,false,C.blue);
};
View.prototype.popsErrors=function(r,m){
 this.neonPanel(r,45,283,2791,470,C.purple);this.icon(r,'logs',77,301,73);this.text(r,'ZAAWANSOWANA DIAGNOSTYKA / '+(m.errorPage+1),164,317,36,C.white);
 const all=wrap(m.errorText||'Brak zgłoszonych błędów',145),offset=Math.max(0,m.errorPage*10);
 all.slice(offset,offset+10).forEach((txt,i)=>this.text(r,txt,110,394+i*24,22,i%2?C.muted:C.white));
 this.premiumButton(r,'error:prev','POPRZEDNIA',null,83,684,515,59,false,false,C.blue);this.premiumButton(r,'error:next','NASTĘPNA',null,613,684,515,59,false,false,C.blue);
 this.premiumButton(r,'error:refresh','ODŚWIEŻ',null,1142,684,516,59,false,false,C.blue);this.premiumButton(r,'retry','POŁĄCZ',null,1670,684,517,59,false,false,C.blue);this.premiumButton(r,'page:settings','USTAWIENIA',null,2202,684,600,59,false,false,C.red);
};
View.prototype.popsCamera=function(r,m){
 this.neonPanel(r,45,283,2791,470,C.blue);this.icon(r,'camera',89,321,158);this.text(r,'KAMERA OEM / STATUS',272,346,45,C.white);
 this.text(r,'BRAK DOSTĘPNEGO INTERFEJSU STRUMIENIA OEM W TYM PAKIECIE',277,439,32,C.yellow);
 this.text(r,'Aplikacja nie wyświetla fikcyjnego obrazu kamery. Sprawdź integrację w Ustawieniach.',277,526,28,C.muted);
 this.premiumButton(r,'page:settings','POWRÓT DO USTAWIEŃ','settings',275,649,990,75,false,false,C.blue);
};
View.prototype.gauges=function(r,m){
 const v=m.frame.values;const theme=THEMES[m.settings.theme]||THEMES[0];
 this.neonPanel(r,45,277,2791,471,theme[1],true);
 this.icon(r,'m',75,289,78);this.text(r,this.config.kind==='cockpit'?'M3 COCKPIT STUDIO':'M3 DUAL GAUGES',172,315,37,C.white);
 this.text(r,theme[0],2784,321,28,theme[1],'right');
 const gauge=(cx,cy,R,val,max,label,unit,c)=>{r.arc(cx,cy,R-18,R,225,495,'#28456b');const p=typeof val==='number'?clamp(val/max,0,1):0;r.arc(cx,cy,R-16,R+6,225,225+270*p,c,{round:true});r.arc(cx,cy,R-16,R+6,455,495,C.red);
  for(let i=0;i<=16;i++){const a=(225+270*i/16)*Math.PI/180;r.line(cx+Math.sin(a)*(R-17),cy-Math.cos(a)*(R-17),cx+Math.sin(a)*(R-33),cy-Math.cos(a)*(R-33),i%4?2:4,'#c3d8f9');}
  const a=(225+270*p)*Math.PI/180;r.line(cx,cy,cx+Math.sin(a)*(R-58),cy-Math.cos(a)*(R-58),7,c);r.circle(cx,cy,14,'#f9f9ff');r.circle(cx,cy,6,c);this.text(r,fmt(val),cx,cy+48,76,C.white,'center');this.text(r,unit,cx,cy+122,27,C.muted,'center');this.text(r,label,cx,cy+R+19,30,C.white,'center');};
 gauge(590,510,157,v.rpm,8000,'OBROTY SILNIKA','RPM',theme[1]);
 gauge(2260,510,157,v.speed,340,'PRĘDKOŚĆ','KM/H',C.ice);
 this.neonPanel(r,1095,372,685,259,C.purple);this.icon(r,'engine',1131,394,107);this.text(r,'M3 COMPETITION',1250,411,33,C.white);
 this.text(r,fmt(v.powerHp),1437,475,79,C.white,'center');this.text(r,'KM  /  MOC WYLICZONA',1437,575,26,C.muted,'center');
 this.premiumButton(r,'theme:prev','<',null,1105,661,137,65,false,false,C.blue);this.premiumButton(r,'page:themes','12 MOTYWÓW','m',1270,661,375,65,false,false,C.purple);this.premiumButton(r,'theme:next','>',null,1665,661,137,65,false,false,C.blue);
};
View.prototype.tabs=function(r,m){
 if(this.config.kind==='pops')return;
 this.premiumButton(r,'page:home','ZEGARY','rpm',43,184,575,72,m.page==='home',false,C.red);
 this.premiumButton(r,'page:themes','MOTYWY','m',638,184,573,72,m.page==='themes',false,C.purple);
 this.premiumButton(r,'page:params','PARAMETRY','wave',1231,184,573,72,m.page==='params',false,C.blue);
 this.premiumButton(r,'page:settings','USTAWIENIA','settings',2230,184,607,72,m.page==='settings',false,C.blue);
};
View.prototype.status=function(r,m){
 const frame=m.frame,live=frame.hasReal&&!frame.demo,col=frame.demo?C.yellow:live?C.green:C.red;
 r.card(43,782,2794,51,13,[[0,'#0a3153'],[.3,'#0a2645'],[1,'#07182a']]);r.strokeRoundRect(43,782,2794,51,13,2,'#3787bf');
 r.circle(78,807,10,col);this.text(r,frame.demo?'DEMO':live?'LIVE':'OFFLINE',104,791,26,col);
 this.text(r,'RPM '+fmt(frame.values.rpm)+'   /   KM/H '+fmt(frame.values.speed),273,791,25,'#c7e6fe');
 this.text(r,'DOTYK '+(m.touchSupported?'AKTYWNY':'NIEDOSTĘPNY'),795,791,24,'#b3c8de');
 this.text(r,'ECU SILNIKA / TYLKO ODCZYT',2000,791,23,C.muted);this.text(r,'BŁĘDY '+(m.errors||0),2798,791,24,(m.errors||0)?C.yellow:C.green,'right');
 this.buttons.push({id:'page:settings',x:43,y:782,w:2794,h:51,kind:'button'});
};

module.exports={View,THEMES,wrap,fmt};


// ================================================================
// M CONTROL REFERENCE MATCH v1.8: exact reference proportions
// Native iDrive top row (0..75) and climate row (840..959) untouched.
// No ECU flashing, single MHD map remains untouched.
// ================================================================
const EX={bg:'#050b17',nav:'#071832',card:'#091b32',white:'#f8fbff',muted:'#9ab4d4',cyan:'#1abaff',red:'#ff245a',purple:'#ab62ed',green:'#28eda5',line:'#28537d'};
View.prototype.illustration=function(r,name,x,y,size){const im=ART.icon(name);if(im)r.image(im,x,y,size,size,0);};
View.prototype.softCard=function(r,x,y,w,h,tint,round){
 const c=tint||EX.cyan, rad=round||16;
 r.card(x-5,y-5,w+10,h+10,rad+4,[[0,c+'40'],[.25,c+'12'],[1,'#050c19']]);
 r.card(x,y,w,h,rad,[[0,'#12345a'],[.105,'#0c274a'],[.32,'#0a203d'],[.7,'#081a34'],[1,'#061226']]);
 r.strokeRoundRect(x,y,w,h,rad,3,c);
 r.roundRect(x+16,y+9,w-32,4,2,c+'aa');
 r.quad([[x+w*.79,y+19],[x+w*.9,y+19],[x+w*.55,y+h-21],[x+w*.45,y+h-21]],'#5bb8ff0a');
};
View.prototype.slimButton=function(r,id,label,icon,x,y,w,h,active,disabled,accent){
 const c=accent||EX.cyan,rad=15;
 if(active){r.card(x-6,y-6,w+12,h+12,20,[[0,c+'66'],[.5,c+'25'],[1,c+'66']]);}
 r.card(x,y,w,h,rad,active?[[0,'#791139'],[.31,'#ff225e'],[.7,'#b41043'],[1,'#300c24']]:[[0,'#234d7a'],[.11,'#17345c'],[.6,'#091e3c'],[1,'#08152e']]);
 r.strokeRoundRect(x,y,w,h,rad,active?4:2,active?'#ff8db0':'#3e78aa');
 r.roundRect(x+16,y+7,w-32,3,2,active?'#ffe3ee88':'#bce5ff65');
 const fs=(label.length>22?23:label.length>14?26:29);
 const txtW=label.length*fs*.54;const isIcon=!!icon;const iconW=isIcon?47:0;const gap=isIcon?14:0;const start=x+(w-txtW-iconW-gap)/2;
 if(icon)this.illustration(r,icon,start,y+(h-47)/2,47);
 this.text(r,label,start+iconW+gap,y+(h-fs)/2-1,fs,disabled?'#7a91a9':'#f8fbff');
 if(id&&!disabled)this.buttons.push({id,x,y,w,h,kind:'button'});
};
View.prototype.softText=function(r,t,x,y,size,color,align){return this.text(r,t,x,y,size,color||EX.white,align);};
View.prototype.softHeading=function(r,t,x,y,icon,size){if(icon)this.illustration(r,icon,x,y-4,58);this.softText(r,t,x+(icon?72:0),y+8,size||34,EX.white);};
View.prototype.backdrop=function(r){
 r.clear([0,0,0,0]);
 r.gradientRect(0,76,2880,764,[[0,'#050a17'],[.19,'#071932'],[.53,'#091a35'],[.83,'#07152d'],[1,'#030814']]);
 // Fine diagonal motor-sport geometry placed behind glass UI
 for(let i=0;i<10;i++){let xx=i*360-160;r.quad([[xx,78],[xx+7,78],[xx-222,839],[xx-229,839]],'#69aeff0b');}
 r.quad([[1570,78],[2130,78],[1690,839],[1140,839]],'#105ba32b');
 r.quad([[2190,78],[2390,78],[1950,839],[1750,839]],'#b9234b19');
 r.gradientRect(0,77,2880,3,[[0,EX.cyan],[.36,'#556cdb'],[.8,EX.red],[1,'#2778d9']]);
 r.gradientRect(0,837,2880,3,[[0,'#2768c2'],[.5,EX.cyan],[.82,EX.red],[1,'#2262bc']]);
};
View.prototype.header=function(r,m){
 r.card(29,88,2822,69,10,[[0,'#133a69'],[.3,'#0c2850'],[.61,'#0d2242'],[1,'#07182f']]);
 r.strokeRoundRect(29,88,2822,69,10,2,'#3165ad');
 r.quad([[1580,89],[1666,89],[1616,156],[1530,156]],'#2a7bd26d');
 r.quad([[1690,89],[1763,89],[1712,156],[1638,156]],'#da235a4d');
 // M triple-bars drawn as geometry, not enlarged photo
 r.quad([[59,102],[82,102],[63,139],[40,139]],'#2ac7ff');
 r.quad([[83,102],[106,102],[87,139],[64,139]],'#4b81f6');
 r.quad([[107,102],[131,102],[112,139],[88,139]],EX.red);
 this.softText(r,'M',150,96,42,EX.white);this.softText(r,'CONTROL',208,106,32,EX.white);
 r.line(430,104,430,144,2,'#7396c1');
 this.softText(r,this.config.kind==='pops'?'Pops Studio':this.config.kind==='cockpit'?'Cockpit Studio':'Dual Gauges',457,108,29,'#dce9ff');
 this.softText(r,'M3 G80',2306,107,27,EX.white);let live=m.frame.hasReal&&!m.frame.demo;let cc=m.frame.demo?C.yellow:live?C.green:C.red;
 r.circle(2513,122,10,cc);this.softText(r,m.frame.demo?'DEMO':live?'DANE LIVE':'BRAK DANYCH',2545,107,27,cc);
};
View.prototype.popsNav=function(r,m){
 let modes=[['comfort','Comfort','eco'],['sport','Sport','sport'],['sportplus','Sport+','m'],['pn','P / N','gear']];
 let widths=[448,448,448,448];let xx=[48,504,960,1416];
 modes.forEach((a,i)=>this.slimButton(r,'mode:'+a[0],a[1],a[2],xx[i],185,widths[i],74,m.settings.mode===a[0]&&m.page==='home',false,m.settings.mode===a[0]?EX.red:EX.cyan));
 this.slimButton(r,'page:camera','Kamera','camera',1917,185,430,74,m.page==='camera',false,EX.cyan);
 this.slimButton(r,'page:settings','Ustawienia','settings',2363,185,470,74,m.page==='settings',false,m.page==='settings'?EX.red:EX.cyan);
};
View.prototype.trackRange=function(r,p,x,y,w){
 this.softText(r,'AKTYWACJA OBROTÓW (ZAKRES RPM)',x,y-50,27,'#d6e5f9');
 this.softText(r,p.rpmMin+' - '+p.rpmMax+' RPM',x+w,y-50,29,EX.white,'right');
 r.roundRect(x,y+18,w,16,8,'#172e51');r.rampRect(x,y+22,w,8,4,[[0,'#147ed6'],[.35,'#39d7e5'],[.62,'#feb75b'],[1,'#ff315f']]);
 const a=x+w*clamp((p.rpmMin-1000)/6600,0,1),b=x+w*clamp((p.rpmMax-1000)/6600,0,1);
 r.roundRect(a,y+18,Math.max(0,b-a),16,7,'#f83c6370');
 [[a,EX.cyan],[b,EX.red]].forEach(q=>{r.circle(q[0],y+26,19,'#ffffff');r.circle(q[0],y+26,12,q[1]);r.circle(q[0],y+26,5,'#ffffff');});
 this.softText(r,'1000',x,y+49,22,'#91a8c5');this.softText(r,'7600',x+w,y+49,22,'#91a8c5','right');
 this.sliders.push({kind:'range',id:'range:rpm',x,y:y-13,w,h:84,min:1000,max:7600,step:100});
};
View.prototype.trackSlider=function(r,id,label,icon,val,min,max,step,x,y,w,unit,disabled){
 this.illustration(r,icon,x,y-45,44);this.softText(r,label,x+52,y-35,26,EX.white);
 this.softText(r,fmt(val,step<1?1:0)+(unit||''),x+w,y-35,26,EX.white,'right');
 r.roundRect(x,y+17,w,12,6,'#122e50');r.rampRect(x,y+20,w,7,4,[[0,'#df2659'],[.35,'#fc4264'],[1,'#fd567b']]);
 const pos=x+w*clamp((val-min)/(max-min),0,1);r.circle(pos,y+23,20,'#ffffff');r.circle(pos,y+23,12,disabled?'#7791b0':EX.red);r.circle(pos,y+23,5,'#ffffff');
 if(!disabled)this.sliders.push({kind:'slider',id,x,y:y-12,w,h:78,min,max,step});
};
View.prototype.telemetry=function(r,m){
 const x=2107,y=283,w=727,h=467;this.softCard(r,x,y,w,h,EX.cyan,17);
 this.softHeading(r,'PARAMETRY LIVE',x+25,y+18,'wave',34);r.line(x+22,y+88,x+w-24,y+88,1,'#4b82b466');
 const v=m.frame.values;let rows=[['AKTUALNA MOC',fmt(v.powerHp),'KM','power'],['OBROTY SILNIKA',fmt(v.rpm),'RPM','rpm'],['DOŁADOWANIE',fmt(v.boost,2),'bar','turbo'],['MOMENT',fmt(v.torque),'Nm','gear'],['TEMP. OLEJU',fmt(v.oil),'°C','engine'],['PŁYN CHŁODZĄCY',fmt(v.coolant),'°C','wave']];
 rows.forEach((row,i)=>{let yy=y+103+57*i;r.line(x+25,yy+46,x+w-23,yy+46,1,'#4b72964a');r.roundRect(x+27,yy+12,4,30,2,i%2?EX.red:EX.cyan);this.illustration(r,row[3],x+42,yy-3,48);this.softText(r,row[0],x+103,yy+9,23,'#bdd1ee');this.softText(r,row[1]+' '+row[2],x+w-25,yy+5,28,EX.white,'right');});
};
View.prototype.pops=function(r,m){
 let mode=m.settings.mode,p=m.settings.profile[mode];const x=47,y=283;
 this.softCard(r,x,y,1331,467,EX.cyan,18);
 this.softHeading(r,'PROFIL '+(mode==='sportplus'?'SPORT+':mode==='pn'?'P / N':mode.toUpperCase())+'  /  USTAWIENIA LOKALNE',74,301,'m',34);
 this.softText(r,'MHD POPS - BRAK MODYFIKACJI ECU',92,380,24,'#d8aebd');
 r.line(86,374,1343,374,2,'#2e669f66');this.trackRange(r,p,91,477,1234);
 this.trackSlider(r,'profile:duration','DŁUGOŚĆ','timer',p.duration,0,4,.1,96,655,357,' s',mode==='comfort');
 this.trackSlider(r,'profile:aggression','MOC','power',p.aggression,0,100,5,536,655,340,' %',mode==='comfort');
 this.trackSlider(r,'profile:delay','OPÓŹNIENIE','delay',p.delay,0,1000,25,974,655,357,' ms',mode==='comfort');
 this.softCard(r,1402,283,682,467,EX.purple,17);this.softHeading(r,'FLAME MODE',1430,305,'flame',35);
 this.softText(r,'TYLKO PODGLĄD / BRAK API ECU',1432,393,24,'#c2a4e6');
 this.slimButton(r,null,'Sport+', 'm',1438,453,608,75,false,true,EX.purple);
 this.slimButton(r,null,'P / N','gear',1438,556,608,75,false,true,EX.purple);
 this.illustration(r,'shield',1441,672,46);this.softText(r,'ECU SILNIKA  /  TYLKO ODCZYT',1500,683,25,'#8ae1fd');
 this.telemetry(r,m);
};
View.prototype.popsSettings=function(r,m){
 // Proportions matched to the two reference images: 3 top cards / 2 bottom cards.
 let y=283;this.softCard(r,46,y,920,290,EX.cyan);this.softHeading(r,'Połączenie',72,303,'shield',34);
 let signals=[['Renderer MGU','połączono',m.touchSupported],['Dotyk','aktywny',m.touchSupported],['Dane LIVE',m.frame.hasReal?'odbierane':'niedostępne',m.frame.hasReal]];
 signals.forEach((a,i)=>{let yy=386+i*60;r.circle(101,yy+14,10,a[2]?EX.green:C.yellow);this.softText(r,a[0],133,yy-1,29,EX.white);this.softText(r,a[1],910,yy-1,27,a[2]?'#a7f6cb':'#efc789','right');});
 this.softCard(r,991,y,1040,290,EX.purple);this.softHeading(r,'Diagnostyka i debug',1015,303,'wave',34);
 this.slimButton(r,'page:errors','Otwórz zaawansowane logi','logs',1032,390,952,69,false,false,EX.purple);
 this.illustration(r,'shield',1033,494,43);this.softText(r,'Ostatni błąd: '+(m.errors?'sprawdź logi':'brak'),1090,497,25,EX.white);
 this.softText(r,'Zdarzenia dotyku: '+m.touchEvents+'    /    RHMI: '+(m.touchSupported?'gotowy':'niepotwierdzony'),1033,536,23,'#bbc5df');
 this.softCard(r,2057,y,775,290,EX.cyan);this.softHeading(r,'Kamera',2083,303,'camera',34);
 this.softText(r,'OEM: brak potwierdzonego API',2094,394,25,C.yellow);
 this.slimButton(r,'page:camera','Test kamery','camera',2091,446,709,62,false,false,EX.cyan);
 this.slimButton(r,'page:camera','Skonfiguruj','settings',2091,518,709,47,false,false,EX.cyan);
 this.softCard(r,46,599,1238,151,EX.cyan);this.softHeading(r,'Interfejs',71,611,'settings',34);
 this.slimButton(r,'page:params','Motyw / Parametry','rpm',74,675,565,61,false,false,EX.cyan);
 this.slimButton(r,'page:graphs','Wykresy','wave',662,675,580,61,false,false,EX.cyan);
 this.softCard(r,1308,599,755,151,EX.purple);this.softHeading(r,'ECU silnika',1331,611,'engine',34);
 this.softText(r,'ECU silnika  /  tylko odczyt',1414,690,28,'#b6ddf1');r.alpha(.60);this.illustration(r,'engine',1890,623,118);r.alpha(1);
 this.softCard(r,2088,599,744,151,EX.cyan);this.softHeading(r,'Kopia i połączenie',2109,611,'shield',34);
 this.slimButton(r,'backup','Kopia','shield',2112,675,321,61,false,false,EX.cyan);
 this.slimButton(r,'retry','Połącz','wave',2448,675,350,61,false,false,EX.cyan);
};
View.prototype.popsErrors=function(r,m){
 this.softCard(r,46,283,2786,467,EX.purple);this.softHeading(r,'ZAAWANSOWANA DIAGNOSTYKA',80,300,'logs',38);
 let a=wrap(m.errorText||'Brak zarejestrowanych błędów',149),start=m.errorPage*10;
 a.slice(start,start+10).forEach((t,i)=>this.softText(r,t,107,390+27*i,22,i%2?'#a4b5cd':EX.white));
 this.slimButton(r,'error:prev','Poprzednia','logs',87,676,470,61,false,false,EX.cyan);
 this.slimButton(r,'error:next','Następna','logs',580,676,470,61,false,false,EX.cyan);
 this.slimButton(r,'error:refresh','Odśwież','wave',1070,676,477,61,false,false,EX.cyan);
 this.slimButton(r,'retry','Połącz ponownie','wave',1568,676,598,61,false,false,EX.cyan);
 this.slimButton(r,'page:settings','Ustawienia','settings',2185,676,601,61,false,false,EX.red);
};
View.prototype.popsCamera=function(r,m){
 this.softCard(r,46,283,2786,467,EX.cyan);this.softHeading(r,'KAMERA',83,305,'camera',40);
 this.softText(r,'Brak potwierdzonego interfejsu strumieniowego OEM na tej jednostce.',111,436,31,C.yellow);
 this.softText(r,'Nie pokazujemy fikcyjnego obrazu. Diagnostyka znajduje się w Ustawieniach.',111,526,29,'#9cb7cf');
 this.slimButton(r,'page:settings','Wróć do ustawień','settings',119,655,971,69,false,false,EX.cyan);
};
View.prototype.status=function(r,m){
 let f=m.frame,live=f.hasReal&&!f.demo,c=f.demo?C.yellow:live?C.green:C.red;
 r.card(43,779,2794,54,9,[[0,'#092b4f'],[.27,'#071c36'],[1,'#071731']]);r.strokeRoundRect(43,779,2794,54,9,2,'#317bc3');
 r.circle(78,805,10,c);this.softText(r,f.demo?'DEMO':live?'LIVE':'OFFLINE',101,789,26,c);
 this.softText(r,'RPM '+fmt(f.values.rpm)+'    |    KM/H '+fmt(f.values.speed),261,789,25,'#cfebff');
 this.softText(r,'BŁĘDY '+(m.errors||0),810,789,25,m.errors?C.yellow:C.green);
 this.softText(r,'DOTYK '+(m.touchSupported?'GOTOWY':'BRAK'),1075,789,24,'#d3eaff');
 this.softText(r,'ECU SILNIKA  /  TYLKO ODCZYT',2050,789,23,'#a5c1da');
 this.buttons.push({id:'page:settings',x:43,y:779,w:2794,h:54,kind:'button'});
};

View.prototype.premiumButton=View.prototype.slimButton;

View.prototype.popsSettings=function(r,m){
 let y=283;
 this.softCard(r,46,y,920,290,EX.cyan);this.softHeading(r,'Połączenie',72,303,'shield',34);
 let sig=[['Renderer MGU',m.touchSupported?'połączono':'niepotwierdzony',m.touchSupported],['Dotyk',m.touchSupported?'aktywny':'niedostępny',m.touchSupported],['Dane LIVE',m.frame.hasReal?'odbierane':'niedostępne',m.frame.hasReal]];
 sig.forEach((a,i)=>{let yy=389+i*59;r.circle(99,yy+11,10,a[2]?EX.green:C.yellow);this.softText(r,a[0],134,yy-2,28,EX.white);this.softText(r,a[1],913,yy-2,25,a[2]?'#96f9c0':'#ebc88c','right');});
 this.softCard(r,990,y,1030,290,EX.purple);this.softHeading(r,'Diagnostyka i debug',1014,303,'wave',34);
 this.slimButton(r,'page:errors','Otwórz zaawansowane logi','logs',1031,388,951,72,false,false,EX.purple);
 this.illustration(r,'shield',1033,489,43);this.softText(r,'Ostatni błąd: '+(m.errors?'szczegóły w logach':'brak'),1090,493,26,EX.white);
 this.softText(r,'Zdarzenia dotyku: '+m.touchEvents+'    /    RHMI: '+(m.touchSupported?'gotowy':'niepotwierdzony'),1033,535,24,'#bbcbe3');
 this.softCard(r,2045,y,787,290,EX.cyan);this.softHeading(r,'Kamera',2073,302,'camera',34);
 this.softText(r,'Kamera OEM: niedostępna',2085,388,27,C.yellow);
 this.slimButton(r,'page:camera','Test kamery','camera',2085,448,709,59,false,false,EX.cyan);
 this.slimButton(r,'page:camera','Konfiguracja','settings',2085,514,709,48,false,false,EX.cyan);
 // Lower row follows the exact two-panel photographic composition.
 this.softCard(r,46,602,1336,148,EX.cyan);
 this.softHeading(r,'Interfejs',72,612,'settings',34);
 this.slimButton(r,'page:graphs','Wykresy','wave',1052,617,285,44,false,false,EX.cyan);
 let opts=[['Motyw: M Control',690],['Jasność: automatyczna',934],['Układ: zoptymalizowany',1179]];
 opts.forEach((a,i)=>{let xx=i===0?103:opts[i-1][1]+13,ww=a[1]-xx;
   this.softText(r,a[0],xx,692,26,'#d7e7fb');this.softText(r,'›',a[1]-19,690,29,EX.white);
   this.buttons.push({id:'page:advanced',x:xx-12,y:676,w:ww+20,h:58,kind:'button'});
   if(i<2)r.line(a[1]+6,677,a[1]+6,733,1,'#2c4f7b');
 });
 this.softCard(r,1405,602,1427,148,EX.purple);
 this.softHeading(r,'ECU silnika',1431,612,'engine',34);
 this.softText(r,'ECU silnika - tylko odczyt',1523,684,27,'#c2daf6');
 r.alpha(.62);this.illustration(r,'engine',2474,609,132);r.alpha(1);
 r.quad([[2723,660],[2738,660],[2708,735],[2693,735]],'#2dc4fb');
 r.quad([[2741,660],[2758,660],[2727,735],[2710,735]],'#627efb');
 r.quad([[2761,660],[2779,660],[2749,735],[2731,735]],EX.red);
 // Additional backup and auto-Demo controls are in Advanced Settings, not on reference screen.
};

// 1.9 reference-calibrated, interactive visual layer: user-supplied screen layouts.
require('./skin19')(View,C,ART,clamp,fmt);
