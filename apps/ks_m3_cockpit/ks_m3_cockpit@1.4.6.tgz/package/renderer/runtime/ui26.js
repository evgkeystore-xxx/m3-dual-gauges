'use strict';
/* M CONTROL 2.6 UI: draws native renderer commands, never writes to ECU. */
module.exports=function(View,Recorder,C,clamp,fmt){
 const baseDraw=View.prototype.draw,baseHeader=View.prototype.header,baseSettings=View.prototype.popsSettings;
 const S={cyan:'#32c2ff',blue:'#168de5',red:'#ff2b63',purple:'#bd59ff',green:'#35f179',amber:'#ffbe38',white:'#f6fbff',muted:'#b9d1eb',dim:'#7f9db9'};
 const tx=(v,r,t,x,y,size=26,color=S.white,align)=>v.text(r,t,x,y,size,color,align);
 const box=(r,x,y,w,h,c=S.cyan)=>{r.card(x,y,w,h,18,[[0,'#143a64'],[.12,'#0b2b4d'],[.57,'#081b31'],[1,'#030d1e']]);r.strokeRoundRect(x,y,w,h,18,3,c);r.roundRect(x+18,y+14,w-36,3,2,c+'7c');};
 const im=(v,r,id,x,y,size=45)=>v.illustration(r,id,x,y,size);
 const head=(v,r,t,x,y,icon,c=S.cyan)=>{if(icon)im(v,r,icon,x,y,48);tx(v,r,t,x+(icon?62:0),y+6,34,S.white);};
 const btn=(v,r,id,label,x,y,w,h,active=false,c=S.cyan)=>{
   r.card(x,y,w,h,13,active?[[0,'#6c183f'],[.5,'#cf1d52'],[1,'#300e2d']]:[[0,'#173f6c'],[.4,'#0b2848'],[1,'#07172c']]);
   r.strokeRoundRect(x,y,w,h,13,active?4:2,active?S.red:c);tx(v,r,label,x+w/2,y+(h-29)/2,28,S.white,'center');
   if(id)v.buttons.push({id,x,y,w,h,kind:'button'});
 };
 const risk=[[0,'#24df64'],[.38,'#b6e72c'],[.62,'#ffb430'],[.81,'#ff7729'],[1,'#ff2055']];
 function slider(v,r,id,label,icon,val,min,max,step,x,y,w,unit,disabled){
   im(v,r,icon,x,y-33,39);tx(v,r,label,x+49,y-29,26);tx(v,r,fmt(val,step<1?1:0)+(unit||''),x+w,y-28,26,S.white,'right');
   const fy=y+20;r.roundRect(x,fy,w,13,7,'#304b65');r.rampRect(x,fy+2,w,9,5,risk);
   const p=clamp((val-min)/(max-min),0,1);r.circle(x+w*p,fy+6,21,'#ffffff');r.circle(x+w*p,fy+6,12,disabled?'#718497':p>.75?S.red:p>.42?S.amber:S.green);
   if(!disabled)v.sliders.push({id,kind:'slider',x,y:y-18,w,h:84,min,max,step});
 }
 function greenRange(v,r,p,x,y,w){
   tx(v,r,'AKTYWACJA (ZAKRES RPM)',x,y-59,27);tx(v,r,p.rpmMin+' – '+p.rpmMax+' RPM',x+w,y-60,29,S.white,'right');
   r.roundRect(x,y,w,16,8,'#294967');const a=x+w*clamp((p.rpmMin-1000)/6600,0,1),b=x+w*clamp((p.rpmMax-1000)/6600,0,1);
   r.roundRect(a,y,Math.max(3,b-a),16,8,S.green);r.line(a,y+3,b,y+3,2,'#b6ffd0');
   [a,b].forEach(q=>{r.circle(q,y+8,20,'#eafffa');r.circle(q,y+8,12,S.green);});
   tx(v,r,'1000',x,y+27,21,S.dim);tx(v,r,'7600',x+w,y+27,21,S.dim,'right');
   v.sliders.push({kind:'range',id:'range:rpm',x,y:y-29,w,h:82,min:1000,max:7600,step:100});
 }
 function stripes(r,x,y,s=1){const colors=[S.cyan,'#586bff',S.red];colors.forEach((color,i)=>r.quad([[x+20*i*s,y],[x+(20*i+14)*s,y],[x+(20*i-3)*s,y+32*s],[x+(20*i-17)*s,y+32*s]],color));}
 View.prototype.m26Header=function(r,m){
   box(r,35,87,2808,80,S.blue);stripes(r,78,110,1.2);tx(this,r,'M CONTROL',190,105,43);r.line(491,104,491,153,2,'#5689b8');tx(this,r,this.config.kind==='pops'?'Pops Controller':'M Control',520,112,32);
   let model=m.settings.carModel||'M3 G80';tx(this,r,model,2190,115,29,S.white);const live=m.frame.hasReal&&!m.frame.demo;r.circle(2515,131,10,live?S.green:m.frame.demo?S.amber:S.red);tx(this,r,live?'DANE LIVE':m.frame.demo?'DEMO':'BRAK DANYCH',2542,114,28,live?S.green:S.amber);
 };
 View.prototype.m26Nav=function(r,m){const q=[['comfort','Comfort','eco'],['sport','Sport','sport'],['sportplus','Sport+','sportplus'],['pn','P/N','gear']];q.forEach((a,i)=>btn(this,r,'mode:'+a[0],a[1],53+i*491,185,475,74,m.settings.mode===a[0],m.settings.mode===a[0]?S.red:S.blue));
  btn(this,r,'page:camera','Kamera',2026,185,383,74,false,S.cyan);btn(this,r,'page:settings','Ustawienia',2424,185,395,74,m.page==='settings',S.cyan);
 };
 View.prototype.m26Telemetry=function(r,m,x=2110,y=283,w=720,h=465,extended=false){
  box(r,x,y,w,h,S.cyan);head(this,r,'PARAMETRY LIVE',x+24,y+24,'wave');if(extended)tx(this,r,m.frame.demo?'DEMO':m.frame.hasReal?'LIVE':'BRAK',x+w-26,y+30,20,m.frame.demo?S.amber:m.frame.hasReal?S.green:S.red,'right');r.line(x+24,y+90,x+w-23,y+90,2,'#376188');
  const v=m.frame.values;const rows=[['Aktualna moc',fmt(v.powerHp),'KM','power'],['Obroty silnika',fmt(v.rpm),'RPM','rpm'],['Doładowanie',fmt(v.boost,2),'bar','boost'],['Moment obrotowy',fmt(v.torque),'Nm','torque'],['Temp. oleju',fmt(v.oil),'°C','oil'],['Płyn chłodzący',fmt(v.coolant),'°C','coolant']];
  if(extended)rows.splice(1,0,['Prędkość',fmt(v.speed),'km/h','rpm']);
  const step=extended?75:56;rows.forEach((q,i)=>{const yy=y+111+i*step;r.line(x+25,yy+step-8,x+w-25,yy+step-8,1,'#274868');im(this,r,q[3],x+32,yy,40);tx(this,r,q[0],x+91,yy+6,25,S.muted);tx(this,r,q[1]+' '+q[2],x+w-27,yy+5,28,S.white,'right');});
 };
 View.prototype.m26Home=function(r,m){const mode=m.settings.mode,p=m.settings.profile[mode],hasFlame=['sportplus','pn'].includes(mode);
  const leftW=hasFlame?1335:2030,leftX=50,y=281,h=471;box(r,leftX,y,leftW,h,S.cyan);stripes(r,leftX+54,y+26,.7);
  tx(this,r,'POPS / PROFIL '+({comfort:'COMFORT',sport:'SPORT',sportplus:'SPORT+',pn:'P/N'}[mode]),leftX+126,y+26,36);
  r.line(leftX+35,y+100,leftX+leftW-35,y+100,1,'#38688c');greenRange(this,r,p,leftX+81,y+221,leftW-160);
  const col=hasFlame?392:604,gap=hasFlame?35:48,start=leftX+76;
  slider(this,r,'profile:duration','DŁUGOŚĆ','timer',p.duration,0,4,.1,start,y+380,col,' s',mode==='comfort');
  slider(this,r,'profile:aggression','MOC','power',p.aggression,0,100,5,start+col+gap,y+380,col,' %',mode==='comfort');
  slider(this,r,'profile:delay','OPÓŹNIENIE','delay',p.delay,0,1000,25,start+2*(col+gap),y+380,col,' ms',mode==='comfort');
  if(hasFlame){const fx=1406,fw=675;box(r,fx,y,fw,h,S.purple);head(this,r,'FLAME MODE',fx+27,y+24,'flame');const f=m.settings.flameProfiles[mode];
   const bx=fx+fw-179,by=y+30;r.roundRect(bx,by,149,60,30,f.enabled?'#0e9f61':'#30415d');r.strokeRoundRect(bx,by,149,60,30,3,f.enabled?S.green:S.dim);
   r.circle(f.enabled?bx+113:bx+35,by+30,24,'#ffffff');tx(this,r,f.enabled?'ON':'OFF',bx+74,by+14,27,S.white,'center');this.buttons.push({id:'flame:toggle',kind:'button',x:bx,y:by,w:149,h:60});
   const defs=[['flame:duration','DŁUGOŚĆ','timer',f.duration,0,4,.1,' s'],['flame:power','MOC','power',f.power,0,100,5,' %'],['flame:delay','OPÓŹNIENIE','delay',f.delay,0,1000,25,' ms']];
   defs.forEach((a,i)=>slider(this,r,a[0],a[1],a[2],a[3],a[4],a[5],a[6],fx+46,y+204+i*81,fw-92,a[7],!f.enabled));
   tx(this,r,'PROFIL LOKALNY',fx+32,y+417,21,S.muted);
  }
  this.m26Telemetry(r,m);
 };
 View.prototype.m26Camera=function(r,m){
  // Camera API not provided by MGU SDK: never substitute a simulated camera image.
  box(r,38,88,2030,736,S.blue);head(this,r,'KAMERA',76,113,'camera');
  r.card(68,190,1971,600,14,[[0,'#01040a'],[1,'#030b16']]);r.strokeRoundRect(68,190,1971,600,14,2,'#2b618f');
  im(this,r,'camera',903,342,180);tx(this,r,'KAMERA OEM — BRAK STRUMIENIA',1050,386,36,S.amber,'center');
  tx(this,r,'Nie wykryto potwierdzonego interfejsu obrazu w tej jednostce MGU.',1050,484,28,S.muted,'center');
  tx(this,r,'Szczegóły: Ustawienia → Diagnostyka. Nie wyświetlamy fikcyjnego obrazu.',1050,538,24,S.dim,'center');
  this.m26Telemetry(r,m,2091,88,744,736,true);
  btn(this,r,'page:home','×',2732,103,82,68,false,S.red);
 };
 function parseRows(m,all){if(all){return (m.debugEntries||[]).map(e=>({code:e.code||'EVENT',msg:String(e.message||''),level:e.level||'INFO',at:e.at||''}));}
  return (m.errorRecords||[]).map(e=>({code:e.code||'BLAD',msg:String(e.message||''),level:e.level||'ERROR',at:e.at||''}));}
 View.prototype.m26Errors=function(r,m){
  const full=!!m.fullDebug;const rows=parseRows(m,full),per=full?65:13,total=Math.max(1,Math.ceil(rows.length/per)),page=clamp(m.errorPage,0,total-1);
  box(r,34,90,2810,731,S.purple);stripes(r,69,113,.85);tx(this,r,'ZAAWANSOWANA DIAGNOSTYKA',146,106,39);
  tx(this,r,full?'PEŁNY DEBUG • 5 KOLUMN':'AKTYWNE BŁĘDY I OSTRZEŻENIA',115,163,26,full?S.green:S.amber);
  tx(this,r,'BŁĘDY '+(m.errors||0)+'  |  STRONA '+(page+1)+' / '+total,2760,109,29,S.white,'right');
  btn(this,r,'debug:toggle',full?'TYLKO BŁĘDY':'PEŁNY DEBUG',2080,148,650,52,full,full?S.red:S.cyan);
  const start=page*per,view=rows.slice(start,start+per);
  if(!view.length)tx(this,r,full?'Brak zapisanych zdarzeń debugowania.':'Brak aktywnych błędów.',100,317,33,S.green);
  if(full){for(let col=0;col<5;col++){const x=58+col*559;box(r,x,224,541,449,col===0?S.red:S.blue);tx(this,r,'LOGI '+(col+1),x+20,239,25,S.white);
    for(let i=0;i<13;i++){const row=view[col*13+i];if(!row)break;const yy=285+i*28;const str=(row.level==='ERROR'?'! ':row.level==='WARN'?'▲ ':'· ')+(row.code||'')+'  '+row.msg.replace(/\s+/g,' ');
      tx(this,r,str.slice(0,41),x+16,yy,17,row.level==='ERROR'?S.red:row.level==='WARN'?S.amber:'#c4d9ee');}}
  }else{const x=58,y=225,w=2755;box(r,x,y,w,447,S.blue);tx(this,r,'POZIOM  |  KOD  |  CZAS  |  KOMUNIKAT',x+23,y+17,25,S.muted);r.line(x+20,y+62,x+w-20,y+62,2,'#46698d');
    view.forEach((e,i)=>{const yy=y+76+i*27;if(i%2===0)r.roundRect(x+21,yy-1,w-42,25,2,'#25456a66');tx(this,r,e.level+'  |  '+e.code+'  |  '+e.at.slice(11,19)+'  |  '+e.msg.replace(/\s+/g,' ').slice(0,164),x+31,yy,19,e.level==='ERROR'?S.red:e.level==='WARN'?S.amber:S.white);});}
  const actions=[['error:prev','POPRZEDNIA'],['error:next','NASTĘPNA'],['error:refresh','ODŚWIEŻ'],['retry','POŁĄCZ PONOWNIE'],['page:settings','USTAWIENIA']];
  actions.forEach((a,i)=>btn(this,r,a[0],a[1],67+i*556,707,529,75,false,i===4?S.red:S.blue));
 };
 View.prototype.m26Settings=function(r,m){
  baseSettings.call(this,r,m);
  // Replaces the lower-left reference panel with a real, local model selector.
  box(r,50,607,1330,151,S.blue);head(this,r,'WYBÓR AUTA',77,622,'m');
  const models=['M3 Competition','M3 CS','M3 CSL','M3','M3 G80','M4 G82','M4 Competition','M4 CSL','M2 G87','M2 CS'];
  const active=m.settings.carModel||'M3 G80';tx(this,r,active,752,670,30,S.white,'center');
  btn(this,r,'model:prev','‹',101,674,131,56,false,S.blue);btn(this,r,'model:next','›',1170,674,156,56,false,S.blue);
  tx(this,r,'Wybór zmienia wyłącznie podpis w aplikacji — nie koduje samochodu.',310,718,19,S.dim);
 };
 View.prototype.draw=function(m){if(this.config.kind!=='pops')return baseDraw.call(this,m);
   this.model=m;this.buttons=[];this.sliders=[];const r=new Recorder(2880,960,{textScale:1});this.backdrop(r);r.clip(0,76,2880,764);
   if(m.page==='camera'){this.m26Camera(r,m);}else if(m.page==='errors'){this.m26Errors(r,m);}else{
     this.m26Header(r,m);this.m26Nav(r,m);
     if(m.page==='settings'){if(m.settingsScroll&&typeof this.popsSettingsExtra==='function')this.popsSettingsExtra(r,m);else this.m26Settings(r,m);if(typeof this.scrollIndicator==='function')this.scrollIndicator(r,m);}
     else if(m.page==='advanced')this.settings(r,m);else if(m.page==='params')this.params(r,m);else if(m.page==='graphs')this.graphs(r,m);
     else if(m.page==='exhaust')this.exhaust(r,m);else this.m26Home(r,m);
     if(m.notice){r.card(600,739,1660,36,9,[[0,'#46223d'],[1,'#151329']]);tx(this,r,String(m.notice).slice(0,120),622,742,23,S.amber);}
     this.status(r,m);
   }
   r.noclip();return r;
 };
};
